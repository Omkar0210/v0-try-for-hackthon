"use client"

import type React from "react"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Card } from "@/components/ui/card"
import { Send, X, MessageSquare } from "lucide-react"

interface ChatWidgetProps {
  isOpen?: boolean
  onClose?: () => void
}

export function ChatWidget({ isOpen = false, onClose }: ChatWidgetProps) {
  const [messages, setMessages] = useState<Array<{ role: string; content: string }>>([])
  const [input, setInput] = useState("")
  const [open, setOpen] = useState(isOpen)

  const handleSendMessage = async (e: React.FormEvent) => {
    e.preventDefault()
    if (!input.trim()) return

    setMessages([...messages, { role: "user", content: input }])
    setInput("")

    // Simulate AI response
    setTimeout(() => {
      setMessages((prev) => [
        ...prev,
        {
          role: "assistant",
          content: "Thanks for your message! How can I help you with CuraLink?",
        },
      ])
    }, 500)
  }

  if (!open) {
    return (
      <button
        onClick={() => setOpen(true)}
        className="fixed bottom-4 right-4 bg-primary text-primary-foreground rounded-full p-4 shadow-lg hover:shadow-xl transition"
      >
        <MessageSquare className="w-6 h-6" />
      </button>
    )
  }

  return (
    <Card className="fixed bottom-4 right-4 w-96 h-96 flex flex-col shadow-xl">
      <div className="flex items-center justify-between p-4 border-b border-border bg-primary text-primary-foreground rounded-t-lg">
        <h3 className="font-semibold">Chat Support</h3>
        <button onClick={() => setOpen(false)}>
          <X className="w-4 h-4" />
        </button>
      </div>

      <div className="flex-1 overflow-auto p-4 space-y-4">
        {messages.map((msg, idx) => (
          <div key={idx} className={`flex ${msg.role === "user" ? "justify-end" : "justify-start"}`}>
            <div
              className={`max-w-xs px-3 py-2 rounded-lg text-sm ${
                msg.role === "user" ? "bg-primary text-primary-foreground" : "bg-secondary text-secondary-foreground"
              }`}
            >
              {msg.content}
            </div>
          </div>
        ))}
      </div>

      <form onSubmit={handleSendMessage} className="p-4 border-t border-border flex gap-2">
        <Input value={input} onChange={(e) => setInput(e.target.value)} placeholder="Type message..." size="sm" />
        <Button type="submit" size="icon" size="sm">
          <Send className="w-4 h-4" />
        </Button>
      </form>
    </Card>
  )
}

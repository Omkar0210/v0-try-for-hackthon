# CuraLink Deployment Guide

## Vercel Deployment Fix

### Issue Encountered
Build error: "Couldn't find any `pages` or `app` directory"

### Root Causes & Solutions
1. **TypeScript Path Alias Issue** - Fixed `tsconfig.json` paths
2. **Next.js Configuration** - Updated `next.config.mjs`
3. **Font Variables** - Fixed font imports in `app/layout.tsx`

### Steps to Deploy Successfully

1. **Update Environment Variables on Vercel:**
   - Go to Project Settings → Environment Variables
   - Add:
     \`\`\`
     VAPI_API_KEY=fa189611-80e1-470c-a3d8-0a941852a956
     VAPI_ASSISTANT_ID=350e5c66-88a2-493d-9958-a2b955ad94de
     MONGODB_URI=your_mongodb_connection_string
     TWILIO_ACCOUNT_SID=your_twilio_sid
     TWILIO_AUTH_TOKEN=your_twilio_token
     TWILIO_PHONE_NUMBER=your_twilio_phone
     \`\`\`

2. **Clear Build Cache:**
   - In Vercel dashboard: Settings → Git → Disconnect and reconnect repository
   - Or manually delete `.next` folder and rebuild

3. **Push Updated Files:**
   - Commit and push these fixed files to GitHub:
     - `tsconfig.json`
     - `next.config.mjs`
     - `app/layout.tsx`
     - `.vercelignore`

4. **Redeploy:**
   - Vercel will auto-deploy on push
   - Monitor build logs in Vercel dashboard

### If Issues Persist

**Option A: Manual Deploy**
\`\`\`bash
npm i -g vercel
vercel --prod
\`\`\`

**Option B: Clear Everything**
1. Delete `.next` folder locally
2. Run `npm run build` locally to test
3. Push to GitHub and redeploy

### Verify Deployment
- Visit your Vercel URL
- Check voice agent page loads
- Test SMS endpoint (POST /api/messages/send-sms)
- Check VAPI webhook configuration

---

## Environment Variables Needed

### VAPI Configuration
\`\`\`
VAPI_API_KEY=fa189611-80e1-470c-a3d8-0a941852a956
VAPI_ASSISTANT_ID=350e5c66-88a2-493d-9958-a2b955ad94de
\`\`\`

### MongoDB Configuration
\`\`\`
MONGODB_URI=mongodb+srv://username:password@cluster.mongodb.net/curalink?retryWrites=true&w=majority
\`\`\`

### Twilio Configuration
\`\`\`
TWILIO_ACCOUNT_SID=your_account_sid
TWILIO_AUTH_TOKEN=your_auth_token
TWILIO_PHONE_NUMBER=+1234567890
\`\`\`

### Get MongoDB URI
1. Go to [MongoDB Atlas](https://account.mongodb.com/account/login)
2. Create/select cluster
3. Click "Connect"
4. Choose "Drivers" → Node.js
5. Copy connection string
6. Replace `<password>` with your database password

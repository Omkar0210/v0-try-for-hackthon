import { MongoClient, type Db } from "mongodb"

// MongoDB Connection Pool
let cachedClient: MongoClient | null = null
let cachedDb: Db | null = null

export async function connectToDatabase() {
  if (cachedClient && cachedDb) {
    return { client: cachedClient, db: cachedDb }
  }

  const mongoUri = process.env.MONGODB_URI

  if (!mongoUri) {
    throw new Error("MONGODB_URI is not defined in environment variables")
  }

  try {
    const client = new MongoClient(mongoUri)
    await client.connect()

    const db = client.db("curalink")

    // Cache the connection
    cachedClient = client
    cachedDb = db

    console.log("[v0] Connected to MongoDB")

    return { client, db }
  } catch (error) {
    console.error("[v0] MongoDB connection failed:", error)
    throw error
  }
}

// Database Collections
export async function getCollections() {
  const { db } = await connectToDatabase()

  return {
    users: db.collection("users"),
    trials: db.collection("clinical_trials"),
    messages: db.collection("messages"),
    voiceLogs: db.collection("voice_call_logs"),
    smsLogs: db.collection("sms_logs"),
    forums: db.collection("forums"),
    enrollments: db.collection("trial_enrollments"),
    chatSessions: db.collection("chat_sessions"), // Added collection for chat history
  }
}

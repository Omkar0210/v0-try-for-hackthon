// VAPI Voice Agent Configuration
export const VAPI_CONFIG = {
  apiKey: process.env.NEXT_PUBLIC_VAPI_API_KEY || "fa189611-80e1-470c-a3d8-0a941852a956",
  assistantId: process.env.NEXT_PUBLIC_VAPI_ASSISTANT_ID || "350e5c66-88a2-493d-9958-a2b955ad94de",
  assistantName: "omkar voice assistant",
}

// Initialize VAPI client
export async function initializeVapi() {
  if (typeof window === "undefined") return null

  try {
    // Dynamically import VAPI SDK
    const VapiClient = (await import("@vapi-ai/web")).default

    const client = new VapiClient({
      apiKey: VAPI_CONFIG.apiKey,
    })

    return client
  } catch (error) {
    console.error("[v0] Failed to initialize VAPI:", error)
    return null
  }
}

// Start voice call with VAPI assistant
export async function startVoiceCall(
  vapiClient: any,
  patientData?: {
    name?: string
    email?: string
    trialId?: string
  },
) {
  try {
    const call = await vapiClient.startCall({
      assistantId: VAPI_CONFIG.assistantId,
      phoneNumberId: undefined, // For web calls
      customerData: patientData,
    })

    return call
  } catch (error) {
    console.error("[v0] Failed to start voice call:", error)
    throw error
  }
}

// Stop voice call
export async function stopVoiceCall(vapiClient: any, callId: string) {
  try {
    await vapiClient.stopCall(callId)
  } catch (error) {
    console.error("[v0] Failed to stop voice call:", error)
    throw error
  }
}

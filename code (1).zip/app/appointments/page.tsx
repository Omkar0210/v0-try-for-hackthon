"use client"

import type React from "react"

import { useEffect, useState } from "react"
import { useRouter } from "next/navigation"
import { Button } from "@/components/ui/button"
import { Card } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Calendar, Clock, CheckCircle, AlertCircle, ArrowLeft } from "lucide-react"
import Link from "next/link"

interface Appointment {
  _id: string
  trial_id: string
  appointment_date: string
  type: string
  status: string
  phone_number: string
}

export default function AppointmentsPage() {
  const router = useRouter()
  const [user, setUser] = useState<any>(null)
  const [appointments, setAppointments] = useState<Appointment[]>([])
  const [loading, setLoading] = useState(true)
  const [showForm, setShowForm] = useState(false)
  const [formData, setFormData] = useState({
    date: "",
    time: "",
    type: "visit",
    trialId: "",
  })

  useEffect(() => {
    const userStr = localStorage.getItem("user")
    if (!userStr) {
      router.push("/auth")
    } else {
      const userData = JSON.parse(userStr)
      setUser(userData)
      loadAppointments(userData.id)
    }
  }, [router])

  const loadAppointments = async (userId: string) => {
    try {
      const response = await fetch(`/api/appointments/list?userId=${userId}`)
      if (response.ok) {
        const data = await response.json()
        setAppointments(data)
      }
    } catch (error) {
      console.error("[v0] Failed to load appointments:", error)
    } finally {
      setLoading(false)
    }
  }

  const handleCreateAppointment = async (e: React.FormEvent) => {
    e.preventDefault()
    if (!formData.date || !formData.time || !formData.trialId) return

    try {
      const response = await fetch("/api/appointments/create", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          userId: user.id,
          trialId: formData.trialId,
          date: formData.date,
          time: formData.time,
          type: formData.type,
          phoneNumber: user.phone || "+1234567890",
        }),
      })

      if (response.ok) {
        setFormData({ date: "", time: "", type: "visit", trialId: "" })
        setShowForm(false)
        loadAppointments(user.id)
      }
    } catch (error) {
      console.error("[v0] Failed to create appointment:", error)
    }
  }

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-background">
        <div className="text-muted-foreground">Loading appointments...</div>
      </div>
    )
  }

  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <header className="border-b border-border bg-card px-6 py-4">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-4">
            <Link href="/dashboard">
              <Button variant="ghost" size="sm">
                <ArrowLeft className="w-4 h-4" />
              </Button>
            </Link>
            <div>
              <h1 className="text-2xl font-bold">My Appointments</h1>
              <p className="text-sm text-muted-foreground">Manage your trial appointments and receive SMS reminders</p>
            </div>
          </div>
          <Button onClick={() => setShowForm(!showForm)} className="gap-2">
            <Calendar className="w-4 h-4" />
            Schedule New
          </Button>
        </div>
      </header>

      {/* Content */}
      <main className="max-w-4xl mx-auto px-6 py-8 space-y-8">
        {/* Appointment Form */}
        {showForm && (
          <Card className="p-6 bg-secondary/30">
            <h2 className="text-lg font-semibold mb-4">Schedule New Appointment</h2>
            <form onSubmit={handleCreateAppointment} className="space-y-4">
              <div className="grid md:grid-cols-2 gap-4">
                <div>
                  <label className="block text-sm font-medium mb-2">Trial ID</label>
                  <Input
                    type="text"
                    placeholder="Enter trial ID"
                    value={formData.trialId}
                    onChange={(e) => setFormData({ ...formData, trialId: e.target.value })}
                    required
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium mb-2">Appointment Type</label>
                  <select
                    className="w-full px-3 py-2 border border-border rounded-lg bg-background"
                    value={formData.type}
                    onChange={(e) => setFormData({ ...formData, type: e.target.value })}
                  >
                    <option>visit</option>
                    <option>screening</option>
                    <option>follow-up</option>
                  </select>
                </div>
                <div>
                  <label className="block text-sm font-medium mb-2">Date</label>
                  <Input
                    type="date"
                    value={formData.date}
                    onChange={(e) => setFormData({ ...formData, date: e.target.value })}
                    required
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium mb-2">Time</label>
                  <Input
                    type="time"
                    value={formData.time}
                    onChange={(e) => setFormData({ ...formData, time: e.target.value })}
                    required
                  />
                </div>
              </div>
              <div className="flex gap-3">
                <Button type="submit">Create Appointment</Button>
                <Button type="button" variant="outline" onClick={() => setShowForm(false)}>
                  Cancel
                </Button>
              </div>
            </form>
          </Card>
        )}

        {/* Appointments List */}
        {appointments.length === 0 ? (
          <Card className="p-12 text-center">
            <AlertCircle className="w-12 h-12 text-muted-foreground mx-auto mb-4 opacity-50" />
            <p className="text-muted-foreground mb-4">No appointments scheduled</p>
            <Button onClick={() => setShowForm(true)}>Schedule Your First Appointment</Button>
          </Card>
        ) : (
          <div className="space-y-4">
            {appointments.map((apt) => (
              <Card key={apt._id} className="p-6 border-l-4 border-l-primary">
                <div className="flex items-start justify-between">
                  <div className="space-y-2">
                    <div className="flex items-center gap-2">
                      <Calendar className="w-5 h-5 text-primary" />
                      <span className="font-semibold">{new Date(apt.appointment_date).toLocaleDateString()}</span>
                    </div>
                    <div className="flex items-center gap-2 text-muted-foreground">
                      <Clock className="w-4 h-4" />
                      <span>{new Date(apt.appointment_date).toLocaleTimeString()}</span>
                    </div>
                    <div className="text-sm text-muted-foreground">
                      Type: <span className="capitalize">{apt.type}</span>
                    </div>
                  </div>
                  <div className="flex items-center gap-2">
                    <CheckCircle className="w-5 h-5 text-green-500" />
                    <span className="capitalize text-sm font-medium">{apt.status}</span>
                  </div>
                </div>
              </Card>
            ))}
          </div>
        )}
      </main>
    </div>
  )
}

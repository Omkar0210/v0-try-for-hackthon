"use client"
import Link from "next/link"
import { useSearchParams } from "next/navigation"
import { Card } from "@/components/ui/card"
import LoginForm from "@/components/auth/login-form"
import SignupForm from "@/components/auth/signup-form"

export default function AuthPage() {
  const searchParams = useSearchParams()
  const mode = searchParams.get("mode") || "login"
  const role = searchParams.get("role") || "patient"

  return (
    <div className="min-h-screen bg-gradient-to-br from-primary/10 to-secondary/10 flex items-center justify-center p-4">
      <Card className="w-full max-w-md">
        <div className="p-8">
          <div className="mb-8">
            <Link href="/" className="flex items-center gap-2 mb-6">
              <div className="w-8 h-8 bg-primary rounded-lg flex items-center justify-center text-primary-foreground font-bold">
                C
              </div>
              <span className="font-bold text-xl">CuraLink</span>
            </Link>
            <h1 className="text-2xl font-bold mb-2">{mode === "signup" ? "Join CuraLink" : "Welcome Back"}</h1>
            <p className="text-muted-foreground">
              {mode === "signup"
                ? "Create an account to find clinical trials or conduct research"
                : "Sign in to your account to continue"}
            </p>
          </div>

          {mode === "signup" ? <SignupForm defaultRole={role} /> : <LoginForm />}

          <div className="mt-6 text-center text-sm text-muted-foreground">
            {mode === "signup" ? (
              <>
                Already have an account?{" "}
                <Link href="/auth?mode=login" className="text-primary hover:underline">
                  Sign in
                </Link>
              </>
            ) : (
              <>
                Don't have an account?{" "}
                <Link href="/auth?mode=signup" className="text-primary hover:underline">
                  Sign up
                </Link>
              </>
            )}
          </div>
        </div>
      </Card>
    </div>
  )
}

"use client"

import { useEffect, useState } from "react"
import { useRouter } from "next/navigation"
import { Card } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Search, Mail, MapPin, Heart, MessageSquare, Filter } from "lucide-react"
import Link from "next/link"

interface Participant {
  _id: string
  name: string
  email: string
  phone: string
  location: string
  conditions: string[]
  age: number
  matchScore: number
  availability: string
}

export default function FindParticipantsPage() {
  const router = useRouter()
  const [participants, setParticipants] = useState<Participant[]>([])
  const [searchTerm, setSearchTerm] = useState("")
  const [loading, setLoading] = useState(true)
  const [user, setUser] = useState<any>(null)
  const [favorites, setFavorites] = useState<Set<string>>(new Set())

  useEffect(() => {
    const userStr = localStorage.getItem("user")
    if (!userStr) {
      router.push("/auth")
    } else {
      setUser(JSON.parse(userStr))
      // Mock data
      setParticipants([
        {
          _id: "p1",
          name: "John Smith",
          email: "john@example.com",
          phone: "+1-555-0101",
          location: "New York, NY",
          conditions: ["Type 2 Diabetes", "Hypertension"],
          age: 52,
          matchScore: 92,
          availability: "Weekdays",
        },
        {
          _id: "p2",
          name: "Sarah Johnson",
          email: "sarah@example.com",
          phone: "+1-555-0102",
          location: "Boston, MA",
          conditions: ["Alzheimer's Risk", "Memory Issues"],
          age: 68,
          matchScore: 88,
          availability: "Flexible",
        },
        {
          _id: "p3",
          name: "Michael Chen",
          email: "michael@example.com",
          phone: "+1-555-0103",
          location: "New York, NY",
          conditions: ["Depression", "Anxiety"],
          age: 35,
          matchScore: 85,
          availability: "Weekends",
        },
      ])
      setLoading(false)
    }
  }, [router])

  const filteredParticipants = participants.filter(
    (p) =>
      p.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
      p.conditions.some((c) => c.toLowerCase().includes(searchTerm.toLowerCase())),
  )

  const toggleFavorite = (id: string) => {
    const newFavorites = new Set(favorites)
    if (newFavorites.has(id)) {
      newFavorites.delete(id)
    } else {
      newFavorites.add(id)
    }
    setFavorites(newFavorites)
  }

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-background">
        <div className="text-muted-foreground">Loading participants...</div>
      </div>
    )
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-background via-background to-secondary/20">
      {/* Header */}
      <header className="border-b border-border/40 bg-card/60 backdrop-blur-xl">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6">
          <Link href="/dashboard" className="text-primary hover:underline mb-4 inline-block text-sm font-medium">
            ← Back to Dashboard
          </Link>
          <h1 className="text-3xl font-bold">Find Participants</h1>
          <p className="text-muted-foreground mt-2">
            Discover patients matched to your research based on conditions and eligibility
          </p>
        </div>
      </header>

      {/* Search & Filter */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <div className="space-y-4">
          <div className="relative">
            <Search className="absolute left-4 top-3 w-5 h-5 text-muted-foreground" />
            <Input
              type="text"
              placeholder="Search by name or medical condition..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="pl-12 h-12 bg-card border-border focus:ring-primary"
            />
          </div>
          <div className="flex gap-2">
            <Button variant="outline" className="gap-2 bg-transparent">
              <Filter className="w-4 h-4" />
              Advanced Filters
            </Button>
          </div>
        </div>
      </section>

      {/* Participants List */}
      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 pb-12">
        {filteredParticipants.length === 0 ? (
          <Card className="p-12 text-center">
            <p className="text-muted-foreground">No participants found</p>
          </Card>
        ) : (
          <div className="space-y-4">
            {filteredParticipants
              .sort((a, b) => b.matchScore - a.matchScore)
              .map((participant) => (
                <Card key={participant._id} className="p-6 hover:shadow-lg transition border-l-4 border-l-primary">
                  <div className="flex items-start justify-between mb-4">
                    <div>
                      <h3 className="text-lg font-bold">{participant.name}</h3>
                      <p className="text-sm text-muted-foreground">{participant.age} years old</p>
                    </div>
                    <div className="flex items-center gap-2 px-3 py-1 rounded-full bg-primary/10">
                      <span className="text-sm font-bold text-primary">{participant.matchScore}%</span>
                      <span className="text-xs text-muted-foreground">Match</span>
                    </div>
                  </div>

                  <div className="grid md:grid-cols-3 gap-4 mb-4">
                    <div>
                      <p className="text-xs text-muted-foreground mb-1">Conditions</p>
                      <div className="flex flex-wrap gap-1">
                        {participant.conditions.map((condition) => (
                          <span key={condition} className="px-2 py-1 bg-secondary text-xs rounded">
                            {condition}
                          </span>
                        ))}
                      </div>
                    </div>
                    <div className="flex items-center gap-2 text-muted-foreground">
                      <MapPin className="w-4 h-4" />
                      <span className="text-sm">{participant.location}</span>
                    </div>
                    <div className="text-sm text-muted-foreground">
                      <p className="text-xs text-muted-foreground mb-1">Availability</p>
                      <p className="font-medium">{participant.availability}</p>
                    </div>
                  </div>

                  <div className="flex gap-2 pt-4 border-t border-border">
                    <Button
                      variant="outline"
                      size="sm"
                      className="flex-1 gap-2 bg-transparent"
                      onClick={() => toggleFavorite(participant._id)}
                    >
                      <Heart
                        className={`w-4 h-4 ${favorites.has(participant._id) ? "fill-current text-destructive" : ""}`}
                      />
                      {favorites.has(participant._id) ? "Saved" : "Save"}
                    </Button>
                    <Button variant="outline" size="sm" className="flex-1 gap-2 bg-transparent">
                      <Mail className="w-4 h-4" />
                      Email
                    </Button>
                    <Button size="sm" className="flex-1 gap-2">
                      <MessageSquare className="w-4 h-4" />
                      Contact
                    </Button>
                  </div>
                </Card>
              ))}
          </div>
        )}
      </main>
    </div>
  )
}

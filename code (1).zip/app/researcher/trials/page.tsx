"use client"

import { useEffect, useState } from "react"
import { useRouter } from "next/navigation"
import { Card } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Plus, Edit, Eye } from "lucide-react"
import Link from "next/link"

interface Trial {
  _id: string
  title: string
  status: string
  phase: string
  participants: number
  targetParticipants: number
  startDate: string
  endDate: string
}

export default function ResearcherTrialsPage() {
  const router = useRouter()
  const [trials, setTrials] = useState<Trial[]>([])
  const [loading, setLoading] = useState(true)
  const [user, setUser] = useState<any>(null)

  useEffect(() => {
    const userStr = localStorage.getItem("user")
    if (!userStr) {
      router.push("/auth")
    } else {
      setUser(JSON.parse(userStr))
      // Mock data
      setTrials([
        {
          _id: "1",
          title: "Diabetes Management Study",
          status: "Active",
          phase: "Phase III",
          participants: 42,
          targetParticipants: 100,
          startDate: "2024-06-01",
          endDate: "2025-12-31",
        },
        {
          _id: "2",
          title: "Heart Health Initiative",
          status: "Active",
          phase: "Phase II",
          participants: 28,
          targetParticipants: 75,
          startDate: "2024-07-15",
          endDate: "2025-07-15",
        },
        {
          _id: "3",
          title: "Cancer Immunotherapy Research",
          status: "Recruiting",
          phase: "Phase I",
          participants: 15,
          targetParticipants: 50,
          startDate: "2024-08-01",
          endDate: "2026-01-31",
        },
      ])
      setLoading(false)
    }
  }, [router])

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-background">
        <div className="text-muted-foreground">Loading trials...</div>
      </div>
    )
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-background via-background to-secondary/20">
      {/* Header */}
      <header className="border-b border-border/40 bg-card/60 backdrop-blur-xl">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6">
          <Link href="/dashboard" className="text-primary hover:underline mb-4 inline-block text-sm font-medium">
            ← Back to Dashboard
          </Link>
          <div className="flex items-center justify-between">
            <div>
              <h1 className="text-3xl font-bold">My Trials</h1>
              <p className="text-muted-foreground mt-2">Manage your clinical research projects</p>
            </div>
            <Button className="gap-2">
              <Plus className="w-4 h-4" />
              New Trial
            </Button>
          </div>
        </div>
      </header>

      {/* Trials Grid */}
      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <div className="space-y-4">
          {trials.map((trial) => {
            const progress = (trial.participants / trial.targetParticipants) * 100

            return (
              <Card key={trial._id} className="p-6 hover:shadow-lg transition border-l-4 border-l-primary">
                <div className="grid md:grid-cols-4 gap-6">
                  {/* Trial Info */}
                  <div>
                    <h3 className="font-bold text-lg mb-2">{trial.title}</h3>
                    <div className="inline-flex items-center gap-2 px-3 py-1 bg-primary/10 text-primary text-xs font-semibold rounded-full">
                      {trial.phase}
                    </div>
                  </div>

                  {/* Stats */}
                  <div>
                    <p className="text-xs text-muted-foreground mb-2">Recruitment Progress</p>
                    <div className="mb-2">
                      <div className="w-full bg-secondary rounded-full h-2 overflow-hidden">
                        <div className="bg-primary h-full transition-all" style={{ width: `${progress}%` }} />
                      </div>
                    </div>
                    <p className="text-sm font-semibold">
                      {trial.participants} / {trial.targetParticipants}
                    </p>
                  </div>

                  {/* Duration */}
                  <div>
                    <p className="text-xs text-muted-foreground mb-2">Duration</p>
                    <p className="text-sm font-semibold">
                      {new Date(trial.startDate).toLocaleDateString()} -
                      <br />
                      {new Date(trial.endDate).toLocaleDateString()}
                    </p>
                  </div>

                  {/* Actions */}
                  <div className="flex gap-2">
                    <Button size="sm" variant="outline" className="flex-1 gap-2 bg-transparent">
                      <Eye className="w-4 h-4" />
                      View
                    </Button>
                    <Button size="sm" className="flex-1 gap-2">
                      <Edit className="w-4 h-4" />
                      Edit
                    </Button>
                  </div>
                </div>
              </Card>
            )
          })}
        </div>
      </main>
    </div>
  )
}

"use client"

import { useEffect, useState } from "react"
import { Card } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { BookOpen, FileText, Video, Download, ExternalLink, Search } from "lucide-react"
import Link from "next/link"

interface Resource {
  _id: string
  title: string
  description: string
  type: "guide" | "article" | "video" | "pdf"
  category: string
  author: string
  date: string
  downloads: number
  url: string
}

export default function ResourcesPage() {
  const [resources, setResources] = useState<Resource[]>([])
  const [searchTerm, setSearchTerm] = useState("")
  const [selectedType, setSelectedType] = useState("all")

  const resourceTypes = [
    { id: "guide", label: "Guides", icon: BookOpen },
    { id: "article", label: "Articles", icon: FileText },
    { id: "video", label: "Videos", icon: Video },
    { id: "pdf", label: "PDFs", icon: Download },
  ]

  useEffect(() => {
    // Mock data
    setResources([
      {
        _id: "1",
        title: "Complete Guide to Clinical Trial Participation",
        description: "Everything you need to know about participating in clinical trials safely and effectively",
        type: "guide",
        category: "Getting Started",
        author: "CuraLink Medical Team",
        date: "2024-11-15",
        downloads: 523,
        url: "/resources/clinical-trial-guide",
      },
      {
        _id: "2",
        title: "Managing Side Effects During Trials",
        description: "Evidence-based strategies for managing medication side effects",
        type: "article",
        category: "Health Management",
        author: "Dr. James Wilson",
        date: "2024-11-20",
        downloads: 234,
        url: "/resources/managing-side-effects",
      },
      {
        _id: "3",
        title: "Patient Rights in Clinical Research",
        description: "Video explaining your rights and protections as a clinical trial participant",
        type: "video",
        category: "Patient Rights",
        author: "Legal Department",
        date: "2024-10-15",
        downloads: 189,
        url: "https://youtube.com/embed/...",
      },
      {
        _id: "4",
        title: "Nutrition During Clinical Trials",
        description: "Comprehensive guide on proper nutrition to support trial participation",
        type: "pdf",
        category: "Health Management",
        author: "Dr. Maria Garcia",
        date: "2024-11-25",
        downloads: 412,
        url: "/resources/nutrition-guide.pdf",
      },
    ])
  }, [])

  const filteredResources = resources.filter((resource) => {
    const matchesSearch = resource.title.toLowerCase().includes(searchTerm.toLowerCase())
    const matchesType = selectedType === "all" || resource.type === selectedType

    return matchesSearch && matchesType
  })

  const getTypeIcon = (type: string) => {
    const typeObj = resourceTypes.find((t) => t.id === type)
    return typeObj?.icon || FileText
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-background via-background to-secondary/20">
      {/* Header */}
      <header className="border-b border-border/40 bg-card/60 backdrop-blur-xl sticky top-0 z-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6">
          <Link href="/dashboard" className="text-primary hover:underline mb-4 inline-block text-sm font-medium">
            ← Back to Dashboard
          </Link>
          <h1 className="text-3xl font-bold">Medical Resources</h1>
          <p className="text-muted-foreground mt-2">Educational materials and guides for clinical trial participants</p>
        </div>
      </header>

      {/* Search & Filter */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <div className="space-y-4">
          <div className="relative">
            <Search className="absolute left-4 top-3 w-5 h-5 text-muted-foreground" />
            <Input
              type="text"
              placeholder="Search resources..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="pl-12 h-12 bg-card border-border focus:ring-primary"
            />
          </div>

          <div className="flex gap-2 flex-wrap">
            <button
              onClick={() => setSelectedType("all")}
              className={`px-4 py-2 rounded-lg font-medium text-sm transition ${
                selectedType === "all"
                  ? "bg-primary text-primary-foreground"
                  : "bg-secondary text-secondary-foreground hover:bg-secondary/80"
              }`}
            >
              All Types
            </button>
            {resourceTypes.map((type) => (
              <button
                key={type.id}
                onClick={() => setSelectedType(type.id)}
                className={`px-4 py-2 rounded-lg font-medium text-sm transition flex items-center gap-2 ${
                  selectedType === type.id
                    ? "bg-primary text-primary-foreground"
                    : "bg-secondary text-secondary-foreground hover:bg-secondary/80"
                }`}
              >
                {type.label}
              </button>
            ))}
          </div>
        </div>
      </section>

      {/* Resources Grid */}
      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 pb-12">
        {filteredResources.length === 0 ? (
          <Card className="p-12 text-center bg-secondary/30">
            <FileText className="w-12 h-12 text-muted-foreground mx-auto mb-4 opacity-50" />
            <p className="text-muted-foreground">No resources found</p>
          </Card>
        ) : (
          <div className="grid md:grid-cols-2 gap-6">
            {filteredResources.map((resource) => {
              const TypeIcon = getTypeIcon(resource.type)
              return (
                <Card
                  key={resource._id}
                  className="p-6 hover:shadow-lg transition border-l-4 border-l-primary flex flex-col"
                >
                  <div className="flex items-start justify-between mb-3">
                    <div className="p-2 rounded-lg bg-primary/10">
                      <TypeIcon className="w-5 h-5 text-primary" />
                    </div>
                    <span className="px-2 py-1 bg-secondary text-secondary-foreground text-xs font-semibold rounded">
                      {resource.category}
                    </span>
                  </div>

                  <h3 className="font-bold text-lg mb-2 flex-1">{resource.title}</h3>
                  <p className="text-sm text-muted-foreground mb-4">{resource.description}</p>

                  <div className="flex items-center justify-between text-xs text-muted-foreground mb-4 pt-4 border-t border-border">
                    <div>
                      <p className="font-medium">{resource.author}</p>
                      <p>{new Date(resource.date).toLocaleDateString()}</p>
                    </div>
                    <p className="text-right">
                      <span className="font-semibold text-foreground">{resource.downloads}</span>
                      <br />
                      Downloads
                    </p>
                  </div>

                  <a href={resource.url} target="_blank" rel="noopener noreferrer">
                    <Button className="w-full gap-2">
                      {resource.type === "pdf" ? "Download" : "View"}
                      {resource.type === "video" ? <Video className="w-4 h-4" /> : <ExternalLink className="w-4 h-4" />}
                    </Button>
                  </a>
                </Card>
              )
            })}
          </div>
        )}
      </main>
    </div>
  )
}

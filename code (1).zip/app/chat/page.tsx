"use client"

import type React from "react"

import { useEffect, useState, useRef } from "react"
import { useRouter } from "next/navigation"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { ArrowLeft, Send, Loader, Trash2, Plus, Copy, ThumbsUp, ThumbsDown } from "lucide-react"
import Link from "next/link"

interface Message {
  id: string
  role: "user" | "assistant"
  content: string
  timestamp: Date
}

interface ChatSession {
  id: string
  title: string
  messages: Message[]
  createdAt: Date
  updatedAt: Date
}

interface User {
  id: string
  name: string
  email: string
}

export default function ChatPage() {
  const router = useRouter()
  const [user, setUser] = useState<User | null>(null)
  const [sessions, setSessions] = useState<ChatSession[]>([])
  const [currentSessionId, setCurrentSessionId] = useState<string | null>(null)
  const [messages, setMessages] = useState<Message[]>([])
  const [input, setInput] = useState("")
  const [loading, setLoading] = useState(true)
  const [streaming, setStreaming] = useState(false)
  const [sidebarOpen, setSidebarOpen] = useState(true)
  const messagesEndRef = useRef<HTMLDivElement>(null)

  useEffect(() => {
    const userStr = localStorage.getItem("user")
    const token = localStorage.getItem("token")

    if (!userStr || !token) {
      router.push("/auth")
    } else {
      setUser(JSON.parse(userStr))
      loadChatSessions()
    }
  }, [router])

  const loadChatSessions = async () => {
    try {
      const response = await fetch("/api/chat/sessions")
      if (response.ok) {
        const data = await response.json()
        setSessions(data)
        if (data.length > 0) {
          setCurrentSessionId(data[0].id)
          setMessages(data[0].messages)
        }
      }
    } catch (error) {
      console.error("[v0] Failed to load sessions:", error)
    } finally {
      setLoading(false)
    }
  }

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" })
  }

  useEffect(() => {
    scrollToBottom()
  }, [messages])

  const createNewSession = async () => {
    try {
      const response = await fetch("/api/chat/sessions", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ title: "New Chat" }),
      })

      if (response.ok) {
        const newSession = await response.json()
        setSessions([newSession, ...sessions])
        setCurrentSessionId(newSession.id)
        setMessages([])
        setInput("")
      }
    } catch (error) {
      console.error("[v0] Failed to create session:", error)
    }
  }

  const deleteSession = async (sessionId: string) => {
    try {
      await fetch(`/api/chat/sessions/${sessionId}`, { method: "DELETE" })
      const newSessions = sessions.filter((s) => s.id !== sessionId)
      setSessions(newSessions)
      if (currentSessionId === sessionId) {
        if (newSessions.length > 0) {
          setCurrentSessionId(newSessions[0].id)
          setMessages(newSessions[0].messages)
        } else {
          createNewSession()
        }
      }
    } catch (error) {
      console.error("[v0] Failed to delete session:", error)
    }
  }

  const handleSendMessage = async (e: React.FormEvent) => {
    e.preventDefault()

    if (!input.trim() || streaming || !currentSessionId) return

    const userMessage: Message = {
      id: Date.now().toString(),
      role: "user",
      content: input,
      timestamp: new Date(),
    }

    setMessages((prev) => [...prev, userMessage])
    setInput("")
    setStreaming(true)

    try {
      const response = await fetch("/api/chat/message", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          sessionId: currentSessionId,
          message: input,
        }),
      })

      if (!response.ok) throw new Error("Failed to send message")

      const reader = response.body?.getReader()
      const decoder = new TextDecoder()
      let assistantMessage = ""

      if (reader) {
        // eslint-disable-next-line no-constant-condition
        while (true) {
          const { done, value } = await reader.read()
          if (done) break

          const chunk = decoder.decode(value)
          assistantMessage += chunk

          setMessages((prev) => {
            const lastMsg = prev[prev.length - 1]
            if (lastMsg?.role === "assistant") {
              return [...prev.slice(0, -1), { ...lastMsg, content: assistantMessage }]
            }
            return [
              ...prev,
              {
                id: (Date.now() + 1).toString(),
                role: "assistant",
                content: assistantMessage,
                timestamp: new Date(),
              },
            ]
          })
        }
      }
    } catch (error) {
      console.error("[v0] Error sending message:", error)
      setMessages((prev) => [
        ...prev,
        {
          id: (Date.now() + 1).toString(),
          role: "assistant",
          content: "Sorry, I encountered an error. Please try again.",
          timestamp: new Date(),
        },
      ])
    } finally {
      setStreaming(false)
    }
  }

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-background">
        <div className="text-center space-y-4">
          <Loader className="w-8 h-8 animate-spin mx-auto text-primary" />
          <p className="text-muted-foreground">Loading your chat sessions...</p>
        </div>
      </div>
    )
  }

  return (
    <div className="min-h-screen bg-background flex flex-col md:flex-row overflow-hidden">
      {/* Sidebar */}
      <div
        className={`${
          sidebarOpen ? "w-64" : "w-0"
        } md:w-64 bg-card border-r border-border flex flex-col transition-all duration-300 overflow-hidden md:overflow-visible`}
      >
        <div className="p-4 border-b border-border space-y-4">
          <Link href="/dashboard">
            <Button variant="ghost" size="sm" className="gap-2 w-full justify-start hover:bg-secondary">
              <ArrowLeft className="w-4 h-4" />
              Back to Dashboard
            </Button>
          </Link>
          <Button onClick={createNewSession} className="w-full gap-2 bg-primary hover:bg-primary/90" size="sm">
            <Plus className="w-4 h-4" />
            New Chat
          </Button>
        </div>

        <div className="flex-1 overflow-auto space-y-2 p-4">
          <p className="text-xs uppercase font-semibold text-muted-foreground px-2 mb-3">Recent Conversations</p>
          {sessions.length === 0 ? (
            <p className="text-sm text-muted-foreground text-center py-8">No conversations yet</p>
          ) : (
            sessions.map((session) => (
              <div
                key={session.id}
                className={`group relative p-3 rounded-lg cursor-pointer transition-all duration-200 ${
                  currentSessionId === session.id
                    ? "bg-primary text-primary-foreground shadow-md"
                    : "hover:bg-secondary bg-muted/30"
                }`}
                onClick={() => {
                  setCurrentSessionId(session.id)
                  setMessages(session.messages)
                }}
              >
                <div className="flex items-center justify-between">
                  <span className="text-sm font-medium truncate flex-1">{session.title}</span>
                  <button
                    onClick={(e) => {
                      e.stopPropagation()
                      deleteSession(session.id)
                    }}
                    className="opacity-0 group-hover:opacity-100 transition p-1 hover:bg-destructive/20 rounded"
                  >
                    <Trash2 className="w-3 h-3" />
                  </button>
                </div>
                <p className="text-xs opacity-70 mt-1">{new Date(session.updatedAt).toLocaleDateString()}</p>
              </div>
            ))
          )}
        </div>
      </div>

      {/* Main Chat Area */}
      <div className="flex-1 flex flex-col">
        {/* Header */}
        <header className="border-b border-border bg-card px-6 py-4 flex items-center justify-between">
          <div>
            <h1 className="text-2xl font-bold text-foreground">CuraLink AI Assistant</h1>
            <p className="text-sm text-muted-foreground">
              Powered by OpenAI GPT-4o • Get answers about clinical trials, health topics & more
            </p>
          </div>
          <button
            onClick={() => setSidebarOpen(!sidebarOpen)}
            className="md:hidden p-2 hover:bg-secondary rounded-lg transition"
          >
            <Plus className="w-5 h-5" />
          </button>
        </header>

        {/* Messages Area */}
        <div className="flex-1 overflow-auto p-6 space-y-4">
          {messages.length === 0 ? (
            <div className="h-full flex items-center justify-center">
              <div className="text-center space-y-4 max-w-md">
                <div className="w-16 h-16 bg-primary/10 rounded-full flex items-center justify-center mx-auto">
                  <svg className="w-8 h-8 text-primary" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path
                      strokeLinecap="round"
                      strokeLinejoin="round"
                      strokeWidth={2}
                      d="M8 10h.01M12 10h.01M16 10h.01M9 16H5a2 2 0 01-2-2V5a2 2 0 012-2h14a2 2 0 012 2v9a2 2 0 01-2 2h-4l-4 4v-4z"
                    />
                  </svg>
                </div>
                <div>
                  <h2 className="text-xl font-semibold mb-2">Start a Conversation</h2>
                  <p className="text-muted-foreground">
                    Ask me anything about clinical trials, eligibility requirements, appointment scheduling, or general
                    health questions.
                  </p>
                </div>
                <div className="grid gap-2 pt-4">
                  <button
                    onClick={() => setInput("What clinical trials are available for my condition?")}
                    className="p-3 text-sm text-left rounded-lg border border-border hover:bg-secondary transition bg-card"
                  >
                    "What clinical trials are available?"
                  </button>
                  <button
                    onClick={() => setInput("How do I know if I'm eligible for a trial?")}
                    className="p-3 text-sm text-left rounded-lg border border-border hover:bg-secondary transition bg-card"
                  >
                    "Am I eligible for a trial?"
                  </button>
                  <button
                    onClick={() => setInput("Tell me about the enrollment process")}
                    className="p-3 text-sm text-left rounded-lg border border-border hover:bg-secondary transition bg-card"
                  >
                    "Tell me about enrollment"
                  </button>
                </div>
              </div>
            </div>
          ) : (
            messages.map((msg) => (
              <div key={msg.id} className={`flex ${msg.role === "user" ? "justify-end" : "justify-start"}`}>
                <div className="flex gap-3 max-w-2xl group">
                  {msg.role === "assistant" && (
                    <div className="w-8 h-8 rounded-full bg-primary/10 flex items-center justify-center flex-shrink-0 mt-1">
                      <span className="text-xs font-bold text-primary">AI</span>
                    </div>
                  )}
                  <div
                    className={`rounded-lg px-4 py-3 ${
                      msg.role === "user"
                        ? "bg-primary text-primary-foreground rounded-br-none"
                        : "bg-secondary text-secondary-foreground rounded-bl-none"
                    }`}
                  >
                    <p className="text-sm whitespace-pre-wrap break-words">{msg.content}</p>
                    {msg.role === "assistant" && (
                      <div className="flex gap-2 mt-2 opacity-0 group-hover:opacity-100 transition">
                        <button
                          onClick={() => navigator.clipboard.writeText(msg.content)}
                          className="p-1 hover:bg-black/10 rounded transition"
                          title="Copy"
                        >
                          <Copy className="w-3 h-3" />
                        </button>
                        <button className="p-1 hover:bg-black/10 rounded transition" title="Helpful">
                          <ThumbsUp className="w-3 h-3" />
                        </button>
                        <button className="p-1 hover:bg-black/10 rounded transition" title="Not helpful">
                          <ThumbsDown className="w-3 h-3" />
                        </button>
                      </div>
                    )}
                  </div>
                </div>
              </div>
            ))
          )}
          {streaming && (
            <div className="flex justify-start">
              <div className="flex gap-3 max-w-2xl">
                <div className="w-8 h-8 rounded-full bg-primary/10 flex items-center justify-center flex-shrink-0 mt-1">
                  <span className="text-xs font-bold text-primary">AI</span>
                </div>
                <div className="bg-secondary text-secondary-foreground px-4 py-3 rounded-lg rounded-bl-none">
                  <div className="flex gap-1">
                    <div className="w-2 h-2 bg-current rounded-full animate-bounce" />
                    <div
                      className="w-2 h-2 bg-current rounded-full animate-bounce"
                      style={{ animationDelay: "0.1s" }}
                    />
                    <div
                      className="w-2 h-2 bg-current rounded-full animate-bounce"
                      style={{ animationDelay: "0.2s" }}
                    />
                  </div>
                </div>
              </div>
            </div>
          )}
          <div ref={messagesEndRef} />
        </div>

        {/* Input Area */}
        <div className="border-t border-border bg-card p-6">
          <form onSubmit={handleSendMessage} className="flex gap-3 max-w-4xl mx-auto">
            <Input
              value={input}
              onChange={(e) => setInput(e.target.value)}
              placeholder="Ask about clinical trials, health topics, or appointment scheduling..."
              disabled={streaming}
              className="flex-1 bg-input border-border focus:ring-primary"
            />
            <Button
              type="submit"
              disabled={streaming || !input.trim()}
              className="gap-2 bg-primary hover:bg-primary/90 text-primary-foreground"
              size="lg"
            >
              {streaming ? <Loader className="w-4 h-4 animate-spin" /> : <Send className="w-4 h-4" />}
              <span className="hidden sm:inline">Send</span>
            </Button>
          </form>
          <p className="text-xs text-muted-foreground text-center mt-3">
            Always consult with your healthcare provider for medical advice
          </p>
        </div>
      </div>
    </div>
  )
}

"use client"

import { useEffect, useState } from "react"
import { useRouter } from "next/navigation"
import { Card } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Calendar, CheckCircle, MessageSquare } from "lucide-react"
import Link from "next/link"

interface EnrolledTrial {
  _id: string
  title: string
  status: string
  enrolledDate: string
  nextAppointment?: string
  progress: number
  sponsor: string
}

export default function MyTrialsPage() {
  const router = useRouter()
  const [trials, setTrials] = useState<EnrolledTrial[]>([])
  const [loading, setLoading] = useState(true)
  const [user, setUser] = useState<any>(null)

  useEffect(() => {
    const userStr = localStorage.getItem("user")
    const token = localStorage.getItem("token")

    if (!userStr || !token) {
      router.push("/auth")
    } else {
      setUser(JSON.parse(userStr))
      // Mock data
      setTrials([
        {
          _id: "1",
          title: "Diabetes Management Study",
          status: "Active",
          enrolledDate: "2024-06-15",
          nextAppointment: "2024-12-20",
          progress: 65,
          sponsor: "MedCorp Research",
        },
        {
          _id: "2",
          title: "Heart Health Research",
          status: "Active",
          enrolledDate: "2024-07-01",
          nextAppointment: "2024-12-25",
          progress: 45,
          sponsor: "Cardiology Institute",
        },
      ])
      setLoading(false)
    }
  }, [router])

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-background">
        <div className="text-muted-foreground">Loading your trials...</div>
      </div>
    )
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-background via-background to-secondary/20">
      {/* Header */}
      <header className="border-b border-border/40 bg-card/60 backdrop-blur-xl">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6">
          <Link href="/dashboard" className="text-primary hover:underline mb-4 inline-block text-sm font-medium">
            ← Back to Dashboard
          </Link>
          <h1 className="text-3xl font-bold">My Enrolled Trials</h1>
          <p className="text-muted-foreground mt-2">Track your trial progress and upcoming appointments</p>
        </div>
      </header>

      {/* Main Content */}
      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {trials.length === 0 ? (
          <Card className="p-12 text-center">
            <CheckCircle className="w-12 h-12 text-muted-foreground mx-auto mb-4 opacity-50" />
            <h2 className="text-xl font-semibold mb-2">No Trials Yet</h2>
            <p className="text-muted-foreground mb-6">
              Start exploring clinical trials to find one that matches your interests
            </p>
            <Link href="/trials">
              <Button>Find Trials</Button>
            </Link>
          </Card>
        ) : (
          <div className="space-y-6">
            {trials.map((trial) => (
              <Card key={trial._id} className="p-6 hover:shadow-lg transition border-l-4 border-l-primary">
                <div className="grid md:grid-cols-3 gap-6">
                  {/* Trial Info */}
                  <div className="md:col-span-1">
                    <h3 className="font-bold text-lg mb-2">{trial.title}</h3>
                    <p className="text-sm text-muted-foreground mb-4">{trial.sponsor}</p>
                    <div className="inline-flex items-center gap-2 px-3 py-1 bg-green-100 text-green-800 text-xs font-semibold rounded-full">
                      <CheckCircle className="w-3 h-3" />
                      {trial.status}
                    </div>
                  </div>

                  {/* Progress */}
                  <div className="md:col-span-1">
                    <p className="text-xs text-muted-foreground mb-2">Progress</p>
                    <div className="mb-2">
                      <div className="w-full bg-secondary rounded-full h-2 overflow-hidden">
                        <div className="bg-primary h-full transition-all" style={{ width: `${trial.progress}%` }} />
                      </div>
                    </div>
                    <p className="text-sm font-semibold">{trial.progress}% Complete</p>
                  </div>

                  {/* Actions */}
                  <div className="md:col-span-1 flex flex-col gap-2">
                    {trial.nextAppointment && (
                      <div className="flex items-center gap-2 p-3 rounded-lg bg-secondary/50">
                        <Calendar className="w-4 h-4 text-accent flex-shrink-0" />
                        <div>
                          <p className="text-xs text-muted-foreground">Next Appointment</p>
                          <p className="text-sm font-semibold">
                            {new Date(trial.nextAppointment).toLocaleDateString()}
                          </p>
                        </div>
                      </div>
                    )}
                    <div className="flex gap-2">
                      <Button size="sm" variant="outline" className="flex-1 gap-2 bg-transparent">
                        <MessageSquare className="w-4 h-4" />
                        Message
                      </Button>
                      <Button size="sm" className="flex-1">
                        Details
                      </Button>
                    </div>
                  </div>
                </div>
              </Card>
            ))}
          </div>
        )}
      </main>
    </div>
  )
}

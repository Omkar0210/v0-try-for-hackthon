import { type NextRequest, NextResponse } from "next/server"

// This webhook receives events from VAPI about voice calls
// Events include: call started, message received, call ended, etc.

export async function POST(request: NextRequest) {
  try {
    const event = await request.json()

    console.log("[v0] VAPI webhook received:", event.type)

    switch (event.type) {
      case "call.started":
        console.log("[v0] Voice call started:", event.callId)
        // Log to database, trigger notifications
        break

      case "call.ended":
        console.log("[v0] Voice call ended:", event.callId)
        // Save call transcript, log duration
        break

      case "message.created":
        console.log("[v0] Message from assistant:", event.message)
        // Log conversation
        break

      case "speech.started":
        console.log("[v0] User started speaking")
        break

      case "speech.ended":
        console.log("[v0] User stopped speaking")
        break

      default:
        console.log("[v0] Unknown VAPI event:", event.type)
    }

    return NextResponse.json({ success: true })
  } catch (error) {
    console.error("[v0] VAPI webhook error:", error)
    return NextResponse.json({ error: "Webhook processing failed" }, { status: 500 })
  }
}

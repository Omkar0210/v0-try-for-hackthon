import { type NextRequest, NextResponse } from "next/server"
import { connectToDatabase } from "@/lib/mongodb"

const accountSid = process.env.TWILIO_ACCOUNT_SID
const authToken = process.env.TWILIO_AUTH_TOKEN
const fromNumber = process.env.TWILIO_PHONE_NUMBER

export async function POST(request: NextRequest) {
  try {
    const { phoneNumber, message, appointmentId } = await request.json()

    if (!phoneNumber || !message) {
      return NextResponse.json({ error: "Missing phone or message" }, { status: 400 })
    }

    if (!accountSid || !authToken || !fromNumber) {
      return NextResponse.json({ error: "Twilio not configured" }, { status: 500 })
    }

    // Send SMS via Twilio
    const response = await fetch(`https://api.twilio.com/2010-04-01/Accounts/${accountSid}/Messages.json`, {
      method: "POST",
      headers: {
        Authorization: `Basic ${Buffer.from(`${accountSid}:${authToken}`).toString("base64")}`,
        "Content-Type": "application/x-www-form-urlencoded",
      },
      body: new URLSearchParams({
        From: fromNumber,
        To: phoneNumber,
        Body: message,
      }).toString(),
    })

    if (!response.ok) {
      throw new Error(`Twilio API error: ${response.statusText}`)
    }

    const twilioResponse = await response.json()

    // Log SMS to database
    const { db } = await connectToDatabase()
    const smsLogsCollection = db.collection("sms_logs")

    await smsLogsCollection.insertOne({
      twilio_message_id: twilioResponse.sid,
      phone_number: phoneNumber,
      message: message,
      appointment_id: appointmentId || null,
      status: "sent",
      created_at: new Date(),
    })

    return NextResponse.json({
      success: true,
      messageId: twilioResponse.sid,
    })
  } catch (error) {
    console.error("[v0] SMS error:", error)
    return NextResponse.json({ error: "Failed to send SMS" }, { status: 500 })
  }
}

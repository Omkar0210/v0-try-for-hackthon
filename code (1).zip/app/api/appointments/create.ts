import { type NextRequest, NextResponse } from "next/server"
import { connectToDatabase } from "@/lib/mongodb"

export async function POST(request: NextRequest) {
  try {
    const { userId, trialId, date, time, type, phoneNumber } = await request.json()

    if (!userId || !trialId || !date || !time || !phoneNumber) {
      return NextResponse.json({ error: "Missing required fields" }, { status: 400 })
    }

    const { db } = await connectToDatabase()
    const appointmentsCollection = db.collection("appointments")

    const appointmentDateTime = new Date(`${date}T${time}`)

    const appointment = {
      user_id: userId,
      trial_id: trialId,
      appointment_date: appointmentDateTime,
      type: type || "visit", // visit, screening, follow-up
      phone_number: phoneNumber,
      status: "scheduled",
      created_at: new Date(),
      updated_at: new Date(),
    }

    const result = await appointmentsCollection.insertOne(appointment)

    // Send confirmation SMS
    const confirmationMessage = `Hi! Your CuraLink appointment is confirmed for ${date} at ${time}. Reply CONFIRM to confirm or CANCEL to cancel.`

    await fetch(new URL("/api/sms/send", request.url).toString(), {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        phoneNumber,
        message: confirmationMessage,
        appointmentId: result.insertedId,
      }),
    })

    return NextResponse.json({
      success: true,
      appointmentId: result.insertedId,
    })
  } catch (error) {
    console.error("[v0] Appointment creation error:", error)
    return NextResponse.json({ error: "Failed to create appointment" }, { status: 500 })
  }
}

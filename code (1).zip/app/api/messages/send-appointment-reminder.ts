import { type NextRequest, NextResponse } from "next/server"

// Send appointment reminder via SMS

export async function POST(request: NextRequest) {
  try {
    const body = await request.json()
    const { patientName, phoneNumber, appointmentDate, appointmentTime, trialName } = body

    const message = `Hi ${patientName}, reminder: You have an appointment for ${trialName} on ${appointmentDate} at ${appointmentTime}. Please confirm or call if you have questions.`

    const smsResponse = await fetch(`${process.env.NEXT_PUBLIC_BASE_URL}/api/messages/send-sms`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        phoneNumber,
        message,
      }),
    })

    const result = await smsResponse.json()

    return NextResponse.json({
      success: smsResponse.ok,
      ...result,
    })
  } catch (error) {
    console.error("[v0] Appointment reminder error:", error)
    return NextResponse.json({ error: "Failed to send reminder" }, { status: 500 })
  }
}

import { type NextRequest, NextResponse } from "next/server"

// Twilio SMS Integration
// This route sends SMS messages to patients for notifications and reminders

const twilioAccountSid = process.env.TWILIO_ACCOUNT_SID
const twilioAuthToken = process.env.TWILIO_AUTH_TOKEN
const twilioPhoneNumber = process.env.TWILIO_PHONE_NUMBER

export async function POST(request: NextRequest) {
  try {
    const body = await request.json()
    const { phoneNumber, message } = body

    if (!phoneNumber || !message) {
      return NextResponse.json({ error: "Missing phoneNumber or message" }, { status: 400 })
    }

    if (!twilioAccountSid || !twilioAuthToken || !twilioPhoneNumber) {
      console.error("[v0] Twilio credentials not configured")
      return NextResponse.json({ error: "SMS service not configured" }, { status: 500 })
    }

    console.log("[v0] Sending SMS to:", phoneNumber)

    // Create Twilio auth header
    const auth = Buffer.from(`${twilioAccountSid}:${twilioAuthToken}`).toString("base64")

    // Send SMS via Twilio API
    const response = await fetch(`https://api.twilio.com/2010-04-01/Accounts/${twilioAccountSid}/Messages.json`, {
      method: "POST",
      headers: {
        Authorization: `Basic ${auth}`,
        "Content-Type": "application/x-www-form-urlencoded",
      },
      body: new URLSearchParams({
        To: phoneNumber,
        From: twilioPhoneNumber,
        Body: message,
      }).toString(),
    })

    const result = await response.json()

    if (!response.ok) {
      console.error("[v0] Twilio error:", result)
      return NextResponse.json({ error: "Failed to send SMS" }, { status: 500 })
    }

    console.log("[v0] SMS sent successfully:", result.sid)

    return NextResponse.json({
      success: true,
      messageId: result.sid,
      status: result.status,
    })
  } catch (error) {
    console.error("[v0] SMS error:", error)
    return NextResponse.json({ error: "Internal server error" }, { status: 500 })
  }
}

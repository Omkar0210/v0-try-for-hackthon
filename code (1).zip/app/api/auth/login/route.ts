import { type NextRequest, NextResponse } from "next/server"

// Mock implementation - replace with actual MongoDB connection
export async function POST(request: NextRequest) {
  try {
    const { email, password } = await request.json()

    if (!email || !password) {
      return NextResponse.json({ error: "Email and password required" }, { status: 400 })
    }

    // Mock authentication - in production, verify against MongoDB
    const user = {
      id: Math.random().toString(36).substr(2, 9),
      name: email.split("@")[0],
      email,
      role: "patient",
    }

    const token = Math.random().toString(36).substr(2)

    return NextResponse.json({ user, token }, { status: 200 })
  } catch (error) {
    return NextResponse.json({ error: "Login failed" }, { status: 500 })
  }
}

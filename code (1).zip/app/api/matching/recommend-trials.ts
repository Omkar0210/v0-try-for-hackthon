import { type NextRequest, NextResponse } from "next/server"
import { connectToDatabase } from "@/lib/mongodb"

export async function POST(request: NextRequest) {
  try {
    const { userId, patientProfile } = await request.json()

    if (!userId) {
      return NextResponse.json({ error: "Missing userId" }, { status: 400 })
    }

    const { db } = await connectToDatabase()
    const trialsCollection = db.collection("clinical_trials")

    // Build query based on patient profile
    const query: any = { status: "active" }

    if (patientProfile?.conditions?.length > 0) {
      query.$or = patientProfile.conditions.map((condition: string) => ({
        condition: { $regex: condition, $options: "i" },
      }))
    }

    if (patientProfile?.ageRange) {
      const [minAge, maxAge] = patientProfile.ageRange
      query.$expr = {
        $and: [
          { $gte: [patientProfile.age, { $toInt: "$minAge" }] },
          { $lte: [patientProfile.age, { $toInt: "$maxAge" }] },
        ],
      }
    }

    // Fetch matching trials
    const matchedTrials = await trialsCollection.find(query).limit(10).toArray()

    // Score and sort matches
    const scoredTrials = matchedTrials.map((trial: any) => {
      let score = 0

      // Condition matching (40 points)
      if (patientProfile?.conditions?.some((c: string) => trial.condition?.toLowerCase().includes(c.toLowerCase()))) {
        score += 40
      }

      // Phase preference (20 points)
      if (patientProfile?.preferredPhase === trial.phase) {
        score += 20
      }

      // Location preference (20 points)
      if (patientProfile?.location && trial.location?.toLowerCase().includes(patientProfile.location.toLowerCase())) {
        score += 20
      }

      // Availability of spots (20 points)
      if (trial.participantsNeeded > trial.currentParticipants) {
        score += 20
      }

      return { ...trial, matchScore: score }
    })

    scoredTrials.sort((a, b) => b.matchScore - a.matchScore)

    return NextResponse.json(scoredTrials)
  } catch (error) {
    console.error("[v0] Matching error:", error)
    return NextResponse.json({ error: "Failed to get recommendations" }, { status: 500 })
  }
}

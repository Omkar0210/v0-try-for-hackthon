import { type NextRequest, NextResponse } from "next/server"
import { connectToDatabase } from "@/lib/mongodb"

export async function POST(request: NextRequest) {
  try {
    const { sessionId, message } = await request.json()

    if (!sessionId || !message) {
      return NextResponse.json({ error: "Missing parameters" }, { status: 400 })
    }

    const apiKey = process.env.OPENAI_API_KEY
    if (!apiKey) {
      return NextResponse.json({ error: "OpenAI API key not configured" }, { status: 500 })
    }

    const encoder = new TextEncoder()
    const stream = new ReadableStream({
      async start(controller) {
        try {
          // Save user message to database immediately
          const { db } = await connectToDatabase()
          const sessionsCollection = db.collection("chat_sessions")

          const userMessageId = Date.now().toString()
          await sessionsCollection.updateOne(
            { _id: sessionId },
            {
              $push: {
                messages: {
                  id: userMessageId,
                  role: "user",
                  content: message,
                  timestamp: new Date(),
                },
              },
            },
          )

          // Get chat history for context
          const session = await sessionsCollection.findOne({ _id: sessionId })
          const messagesHistory = (session?.messages || []).slice(-10).map((msg: any) => ({
            role: msg.role,
            content: msg.content,
          }))

          // Call OpenAI API with streaming
          const response = await fetch("https://api.openai.com/v1/chat/completions", {
            method: "POST",
            headers: {
              "Content-Type": "application/json",
              Authorization: `Bearer ${apiKey}`,
            },
            body: JSON.stringify({
              model: "gpt-4o-mini",
              messages: [
                {
                  role: "system",
                  content: `You are CuraLink AI Assistant, a helpful healthcare advisor for clinical trials and patient care. 
                  You provide accurate, compassionate information about:
                  - Clinical trials and enrollment
                  - Patient eligibility and requirements
                  - Appointment scheduling
                  - General health information
                  - Trial side effects and expectations
                  
                  Keep responses concise, clear, and patient-friendly. Always encourage users to consult with their healthcare provider for medical decisions.`,
                },
                ...messagesHistory,
                { role: "user", content: message },
              ],
              stream: true,
              max_tokens: 1024,
              temperature: 0.7,
            }),
          })

          if (!response.ok) {
            throw new Error(`OpenAI API error: ${response.statusText}`)
          }

          const reader = response.body?.getReader()
          const decoder = new TextDecoder()
          let assistantContent = ""

          if (reader) {
            // eslint-disable-next-line no-constant-condition
            while (true) {
              const { done, value } = await reader.read()
              if (done) break

              const chunk = decoder.decode(value, { stream: true })
              const lines = chunk.split("\n")

              for (const line of lines) {
                if (line.startsWith("data: ")) {
                  const data = line.slice(6)
                  if (data === "[DONE]") continue

                  try {
                    const parsed = JSON.parse(data)
                    const content = parsed.choices[0]?.delta?.content || ""
                    if (content) {
                      assistantContent += content
                      controller.enqueue(encoder.encode(content))
                    }
                  } catch (e) {
                    // Skip parsing errors
                  }
                }
              }
            }
          }

          // Save assistant message to database
          await sessionsCollection.updateOne(
            { _id: sessionId },
            {
              $push: {
                messages: {
                  id: (Date.now() + 1).toString(),
                  role: "assistant",
                  content: assistantContent,
                  timestamp: new Date(),
                },
              },
              $set: { updatedAt: new Date() },
            },
          )

          controller.close()
        } catch (error) {
          console.error("[v0] Stream error:", error)
          controller.error(error)
        }
      },
    })

    return new NextResponse(stream, {
      headers: { "Content-Type": "text/event-stream" },
    })
  } catch (error) {
    console.error("[v0] Chat message error:", error)
    return NextResponse.json({ error: "Failed to process message" }, { status: 500 })
  }
}

import { type NextRequest, NextResponse } from "next/server"
import { connectToDatabase } from "@/lib/mongodb"
import { ObjectId } from "mongodb"

export async function GET(request: NextRequest) {
  try {
    const { db } = await connectToDatabase()
    const sessions = await db.collection("chat_sessions").find({}).toArray()

    return NextResponse.json(sessions)
  } catch (error) {
    console.error("[v0] Failed to fetch sessions:", error)
    return NextResponse.json({ error: "Failed to fetch sessions" }, { status: 500 })
  }
}

export async function POST(request: NextRequest) {
  try {
    const { title } = await request.json()
    const { db } = await connectToDatabase()

    const newSession = {
      _id: new ObjectId(),
      title: title || "New Chat",
      messages: [],
      createdAt: new Date(),
      updatedAt: new Date(),
    }

    const result = await db.collection("chat_sessions").insertOne(newSession)

    return NextResponse.json({
      id: result.insertedId.toString(),
      ...newSession,
    })
  } catch (error) {
    console.error("[v0] Failed to create session:", error)
    return NextResponse.json({ error: "Failed to create session" }, { status: 500 })
  }
}

import { type NextRequest, NextResponse } from "next/server"
import { connectToDatabase } from "@/lib/mongodb"

export async function GET(request: NextRequest) {
  try {
    const { searchParams } = new URL(request.url)
    const query = searchParams.get("q") || ""
    const status = searchParams.get("status") || "active"
    const phase = searchParams.get("phase")

    const { db } = await connectToDatabase()
    const trialsCollection = db.collection("clinical_trials")

    const filter: any = { status }
    if (query) {
      filter.$text = { $search: query }
    }
    if (phase) {
      filter.phase = phase
    }

    const trials = await trialsCollection.find(filter).limit(50).toArray()

    return NextResponse.json(trials)
  } catch (error) {
    console.error("[v0] Trials search error:", error)
    return NextResponse.json({ error: "Failed to search trials" }, { status: 500 })
  }
}

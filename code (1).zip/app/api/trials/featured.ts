import { type NextRequest, NextResponse } from "next/server"
import { connectToDatabase } from "@/lib/mongodb"

export async function GET(request: NextRequest) {
  try {
    const { db } = await connectToDatabase()
    const trialsCollection = db.collection("clinical_trials")

    const trials = await trialsCollection.find({ status: "active", featured: true }).limit(6).toArray()

    return NextResponse.json(trials)
  } catch (error) {
    console.error("[v0] Featured trials error:", error)
    return NextResponse.json({ error: "Failed to fetch featured trials" }, { status: 500 })
  }
}

import { type NextRequest, NextResponse } from "next/server"
import { connectToDatabase } from "@/lib/mongodb"
import { ObjectId } from "mongodb"

export async function POST(request: NextRequest, { params }: { params: { id: string } }) {
  try {
    const { userId } = await request.json()
    const trialId = params.id

    if (!userId) {
      return NextResponse.json({ error: "Missing userId" }, { status: 400 })
    }

    const { db } = await connectToDatabase()
    const enrollmentsCollection = db.collection("enrollments")
    const trialsCollection = db.collection("clinical_trials")

    // Check if already enrolled
    const existingEnrollment = await enrollmentsCollection.findOne({
      user_id: userId,
      trial_id: new ObjectId(trialId),
    })

    if (existingEnrollment) {
      return NextResponse.json({ error: "Already enrolled in this trial" }, { status: 409 })
    }

    // Create enrollment
    const enrollment = {
      user_id: userId,
      trial_id: new ObjectId(trialId),
      status: "active",
      enrolled_date: new Date(),
      updated_at: new Date(),
    }

    const result = await enrollmentsCollection.insertOne(enrollment)

    // Update trial participant count
    await trialsCollection.updateOne({ _id: new ObjectId(trialId) }, { $inc: { participant_count: 1 } })

    return NextResponse.json({
      success: true,
      enrollmentId: result.insertedId,
    })
  } catch (error) {
    console.error("[v0] Enrollment error:", error)
    return NextResponse.json({ error: "Failed to enroll" }, { status: 500 })
  }
}

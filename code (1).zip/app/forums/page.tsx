"use client"

import { useEffect, useState } from "react"
import { useRouter } from "next/navigation"
import { Card } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { MessageSquare, Eye, ThumbsUp, Plus, Search } from "lucide-react"
import Link from "next/link"

interface ForumThread {
  _id: string
  title: string
  category: string
  author: string
  replies: number
  views: number
  likes: number
  lastReply: string
  isPinned: boolean
}

export default function ForumsPage() {
  const router = useRouter()
  const [threads, setThreads] = useState<ForumThread[]>([])
  const [searchTerm, setSearchTerm] = useState("")
  const [selectedCategory, setSelectedCategory] = useState("all")
  const [loading, setLoading] = useState(true)
  const [user, setUser] = useState<any>(null)

  const categories = [
    "General Discussion",
    "Trial Experiences",
    "Health & Wellness",
    "Medication Side Effects",
    "Success Stories",
    "Questions & Answers",
  ]

  useEffect(() => {
    const userStr = localStorage.getItem("user")
    if (!userStr) {
      router.push("/auth")
    } else {
      setUser(JSON.parse(userStr))
      // Mock data
      setThreads([
        {
          _id: "1",
          title: "My experience with the Diabetes Study - 3 months in",
          category: "Trial Experiences",
          author: "Jennifer M.",
          replies: 23,
          views: 342,
          likes: 67,
          lastReply: "2024-12-15",
          isPinned: true,
        },
        {
          _id: "2",
          title: "Dealing with medication side effects",
          category: "Medication Side Effects",
          author: "Robert K.",
          replies: 45,
          views: 876,
          likes: 112,
          lastReply: "2024-12-16",
          isPinned: true,
        },
        {
          _id: "3",
          title: "Tips for managing trial appointments",
          category: "General Discussion",
          author: "Maria S.",
          replies: 18,
          views: 254,
          likes: 43,
          lastReply: "2024-12-14",
          isPinned: false,
        },
        {
          _id: "4",
          title: "How to prepare for your first screening visit",
          category: "Questions & Answers",
          author: "Dr. Anderson",
          replies: 31,
          views: 598,
          likes: 89,
          lastReply: "2024-12-15",
          isPinned: false,
        },
        {
          _id: "5",
          title: "Success Story: I'm now in remission!",
          category: "Success Stories",
          author: "Thomas L.",
          replies: 52,
          views: 1203,
          likes: 245,
          lastReply: "2024-12-16",
          isPinned: false,
        },
        {
          _id: "6",
          title: "Best practices for clinical trial participation",
          category: "Health & Wellness",
          author: "Dr. Chen",
          replies: 27,
          views: 445,
          likes: 76,
          lastReply: "2024-12-14",
          isPinned: false,
        },
      ])
      setLoading(false)
    }
  }, [router])

  const filteredThreads = threads.filter((thread) => {
    const matchesSearch = thread.title.toLowerCase().includes(searchTerm.toLowerCase())
    const matchesCategory = selectedCategory === "all" || thread.category === selectedCategory

    return matchesSearch && matchesCategory
  })

  return (
    <div className="min-h-screen bg-gradient-to-br from-background via-background to-secondary/20">
      {/* Header */}
      <header className="border-b border-border/40 bg-card/60 backdrop-blur-xl sticky top-0 z-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6">
          <Link href="/dashboard" className="text-primary hover:underline mb-4 inline-block text-sm font-medium">
            ← Back to Dashboard
          </Link>
          <div className="flex items-center justify-between">
            <div>
              <h1 className="text-3xl font-bold">Community Forums</h1>
              <p className="text-muted-foreground mt-2">Connect with other trial participants and share experiences</p>
            </div>
            <Button className="gap-2">
              <Plus className="w-4 h-4" />
              New Thread
            </Button>
          </div>
        </div>
      </header>

      {/* Search & Category Filter */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <div className="space-y-4">
          <div className="relative">
            <Search className="absolute left-4 top-3 w-5 h-5 text-muted-foreground" />
            <Input
              type="text"
              placeholder="Search discussions..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="pl-12 h-12 bg-card border-border focus:ring-primary"
            />
          </div>

          <div className="flex gap-2 overflow-x-auto pb-2">
            <button
              onClick={() => setSelectedCategory("all")}
              className={`px-4 py-2 rounded-lg font-medium text-sm whitespace-nowrap transition ${
                selectedCategory === "all"
                  ? "bg-primary text-primary-foreground"
                  : "bg-secondary text-secondary-foreground hover:bg-secondary/80"
              }`}
            >
              All Categories
            </button>
            {categories.map((cat) => (
              <button
                key={cat}
                onClick={() => setSelectedCategory(cat)}
                className={`px-4 py-2 rounded-lg font-medium text-sm whitespace-nowrap transition ${
                  selectedCategory === cat
                    ? "bg-primary text-primary-foreground"
                    : "bg-secondary text-secondary-foreground hover:bg-secondary/80"
                }`}
              >
                {cat}
              </button>
            ))}
          </div>
        </div>
      </section>

      {/* Forum Threads */}
      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 pb-12">
        {loading ? (
          <Card className="p-12 text-center">
            <p className="text-muted-foreground">Loading discussions...</p>
          </Card>
        ) : filteredThreads.length === 0 ? (
          <Card className="p-12 text-center bg-secondary/30">
            <MessageSquare className="w-12 h-12 text-muted-foreground mx-auto mb-4 opacity-50" />
            <p className="text-muted-foreground mb-4">No discussions found</p>
            <Button onClick={() => setSearchTerm("")}>Clear Search</Button>
          </Card>
        ) : (
          <div className="space-y-4">
            {filteredThreads.map((thread) => (
              <Link key={thread._id} href={`/forums/${thread._id}`}>
                <Card className="p-6 hover:shadow-lg transition cursor-pointer border-l-4 border-l-primary hover:border-l-accent group">
                  <div className="flex items-start justify-between mb-3">
                    <div className="flex-1">
                      <div className="flex items-center gap-2 mb-2">
                        {thread.isPinned && (
                          <span className="px-2 py-1 bg-accent/10 text-accent text-xs font-semibold rounded">
                            PINNED
                          </span>
                        )}
                        <span className="px-2 py-1 bg-primary/10 text-primary text-xs font-semibold rounded">
                          {thread.category}
                        </span>
                      </div>
                      <h3 className="text-lg font-bold line-clamp-2 group-hover:text-primary transition">
                        {thread.title}
                      </h3>
                    </div>
                  </div>

                  <div className="flex items-center justify-between text-sm text-muted-foreground">
                    <div className="space-y-1">
                      <p>
                        Started by <span className="font-medium text-foreground">{thread.author}</span>
                      </p>
                      <p>Last reply {new Date(thread.lastReply).toLocaleDateString()}</p>
                    </div>

                    <div className="grid grid-cols-3 gap-6 text-right">
                      <div>
                        <p className="font-bold text-foreground">{thread.replies}</p>
                        <p className="flex items-center gap-1 justify-end">
                          <MessageSquare className="w-4 h-4" />
                          Replies
                        </p>
                      </div>
                      <div>
                        <p className="font-bold text-foreground">{thread.views}</p>
                        <p className="flex items-center gap-1 justify-end">
                          <Eye className="w-4 h-4" />
                          Views
                        </p>
                      </div>
                      <div>
                        <p className="font-bold text-foreground">{thread.likes}</p>
                        <p className="flex items-center gap-1 justify-end">
                          <ThumbsUp className="w-4 h-4" />
                          Likes
                        </p>
                      </div>
                    </div>
                  </div>
                </Card>
              </Link>
            ))}
          </div>
        )}
      </main>
    </div>
  )
}

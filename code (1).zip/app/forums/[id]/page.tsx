"use client"

import type React from "react"

import { useEffect, useState } from "react"
import { useRouter, useParams } from "next/navigation"
import { Card } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { ArrowLeft, MessageSquare, ThumbsUp, Flag, Share2 } from "lucide-react"
import Link from "next/link"

interface ForumReply {
  _id: string
  author: string
  role: "patient" | "researcher" | "moderator"
  content: string
  likes: number
  date: string
}

interface ForumThread {
  _id: string
  title: string
  category: string
  author: string
  authorRole: "patient" | "researcher"
  content: string
  likes: number
  views: number
  replies: ForumReply[]
  createdAt: string
}

export default function ForumThreadPage() {
  const router = useRouter()
  const params = useParams()
  const threadId = params.id as string

  const [thread, setThread] = useState<ForumThread | null>(null)
  const [replyText, setReplyText] = useState("")
  const [loading, setLoading] = useState(true)
  const [user, setUser] = useState<any>(null)

  useEffect(() => {
    const userStr = localStorage.getItem("user")
    if (!userStr) {
      router.push("/auth")
    } else {
      setUser(JSON.parse(userStr))
      // Mock data
      setThread({
        _id: threadId,
        title: "My experience with the Diabetes Study - 3 months in",
        category: "Trial Experiences",
        author: "Jennifer M.",
        authorRole: "patient",
        content:
          "I've been enrolled in the Diabetes Management Study for 3 months now and wanted to share my experience. The research team has been incredible - very supportive and responsive. The new insulin therapy combined with the CGM has made managing my blood sugar much easier. The monthly appointments are convenient and the staff is always professional.",
        likes: 67,
        views: 342,
        replies: [
          {
            _id: "r1",
            author: "Michael T.",
            role: "patient",
            content:
              "Thanks for sharing! I'm in the same trial and having similar positive experiences. The weekly check-ins have been helpful.",
            likes: 12,
            date: "2024-12-15",
          },
          {
            _id: "r2",
            author: "Dr. Sarah Chen",
            role: "researcher",
            content:
              "Thank you for the positive feedback, Jennifer! We're glad the trial is going well for you. Keep up the great work with your appointments.",
            likes: 28,
            date: "2024-12-14",
          },
        ],
        createdAt: "2024-12-10",
      })
      setLoading(false)
    }
  }, [threadId, router])

  const handleReply = async (e: React.FormEvent) => {
    e.preventDefault()
    if (!replyText.trim() || !user || !thread) return

    // Mock reply addition
    const newReply: ForumReply = {
      _id: Date.now().toString(),
      author: user.name,
      role: "patient",
      content: replyText,
      likes: 0,
      date: new Date().toLocaleDateString(),
    }

    setThread({
      ...thread,
      replies: [...thread.replies, newReply],
    })
    setReplyText("")
  }

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-background">
        <div className="text-muted-foreground">Loading discussion...</div>
      </div>
    )
  }

  if (!thread) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-background">
        <div className="text-center">
          <p className="text-muted-foreground mb-4">Discussion not found</p>
          <Link href="/forums">
            <Button>Back to Forums</Button>
          </Link>
        </div>
      </div>
    )
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-background via-background to-secondary/20">
      {/* Header */}
      <header className="border-b border-border/40 bg-card/60 backdrop-blur-xl sticky top-0 z-50">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-4">
          <Link href="/forums">
            <Button variant="ghost" size="sm" className="gap-2 mb-4">
              <ArrowLeft className="w-4 h-4" />
              Back to Forums
            </Button>
          </Link>
          <h1 className="text-2xl font-bold line-clamp-2">{thread.title}</h1>
        </div>
      </header>

      {/* Main Content */}
      <main className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* Original Post */}
        <Card className="p-8 mb-8 border-l-4 border-l-primary">
          <div className="flex items-start justify-between mb-6">
            <div>
              <div className="flex items-center gap-2 mb-2">
                <span className="px-3 py-1 bg-primary/10 text-primary text-xs font-semibold rounded-full">
                  {thread.category}
                </span>
                <span className="text-xs text-muted-foreground capitalize">
                  {thread.authorRole === "researcher" ? "Research Team" : "Community Member"}
                </span>
              </div>
              <h2 className="text-xl font-bold mb-1">{thread.author}</h2>
              <p className="text-sm text-muted-foreground">{new Date(thread.createdAt).toLocaleDateString()}</p>
            </div>
            <div className="flex gap-2">
              <Button variant="outline" size="icon">
                <Share2 className="w-4 h-4" />
              </Button>
              <Button variant="outline" size="icon">
                <Flag className="w-4 h-4" />
              </Button>
            </div>
          </div>

          <p className="text-muted-foreground mb-6 leading-relaxed">{thread.content}</p>

          <div className="flex items-center gap-6 pt-6 border-t border-border">
            <button className="flex items-center gap-2 text-muted-foreground hover:text-primary transition">
              <ThumbsUp className="w-5 h-5" />
              <span className="text-sm font-medium">{thread.likes} Likes</span>
            </button>
            <div className="flex items-center gap-2 text-muted-foreground">
              <MessageSquare className="w-5 h-5" />
              <span className="text-sm font-medium">{thread.replies.length} Replies</span>
            </div>
          </div>
        </Card>

        {/* Replies */}
        <div className="space-y-4 mb-8">
          <h3 className="font-bold text-lg">Replies ({thread.replies.length})</h3>
          {thread.replies.map((reply) => (
            <Card key={reply._id} className="p-6">
              <div className="flex items-start justify-between mb-4">
                <div>
                  <div className="flex items-center gap-2 mb-1">
                    <h4 className="font-semibold">{reply.author}</h4>
                    {reply.role === "researcher" && (
                      <span className="px-2 py-1 bg-accent/10 text-accent text-xs font-semibold rounded">
                        Research Team
                      </span>
                    )}
                    {reply.role === "moderator" && (
                      <span className="px-2 py-1 bg-primary/10 text-primary text-xs font-semibold rounded">
                        Moderator
                      </span>
                    )}
                  </div>
                  <p className="text-xs text-muted-foreground">{reply.date}</p>
                </div>
              </div>
              <p className="text-muted-foreground mb-4">{reply.content}</p>
              <button className="flex items-center gap-2 text-sm text-muted-foreground hover:text-primary transition">
                <ThumbsUp className="w-4 h-4" />
                {reply.likes > 0 && <span>{reply.likes}</span>}
                <span>Like</span>
              </button>
            </Card>
          ))}
        </div>

        {/* Reply Form */}
        <Card className="p-6">
          <h3 className="font-bold mb-4">Add Your Reply</h3>
          <form onSubmit={handleReply} className="space-y-4">
            <textarea
              value={replyText}
              onChange={(e) => setReplyText(e.target.value)}
              placeholder="Share your thoughts or experience..."
              className="w-full p-4 border border-border rounded-lg bg-background focus:ring-2 focus:ring-primary resize-none min-h-24"
            />
            <div className="flex gap-2">
              <Button type="submit" disabled={!replyText.trim()}>
                Post Reply
              </Button>
              <Button type="button" variant="outline" onClick={() => setReplyText("")}>
                Clear
              </Button>
            </div>
          </form>
        </Card>
      </main>
    </div>
  )
}

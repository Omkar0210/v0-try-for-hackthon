"use client"

import { useEffect, useState } from "react"
import { useRouter, useParams } from "next/navigation"
import { Card } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { ArrowLeft, MapPin, Users, Clock, CheckCircle, Heart, Share2, Phone, Mail } from "lucide-react"
import Link from "next/link"

interface Trial {
  _id: string
  title: string
  description: string
  fullDescription: string
  status: string
  location: string
  phase: string
  sponsor: string
  participantsNeeded: number
  currentParticipants: number
  startDate: string
  endDate: string
  condition: string
  requirements: string[]
  sideEffects: string[]
  benefits: string[]
  contactName: string
  contactEmail: string
  contactPhone: string
}

export default function TrialDetailPage() {
  const router = useRouter()
  const params = useParams()
  const trialId = params.id as string

  const [trial, setTrial] = useState<Trial | null>(null)
  const [loading, setLoading] = useState(true)
  const [user, setUser] = useState<any>(null)
  const [enrolling, setEnrolling] = useState(false)
  const [enrolled, setEnrolled] = useState(false)

  useEffect(() => {
    const userStr = localStorage.getItem("user")
    if (!userStr) {
      router.push("/auth")
    } else {
      setUser(JSON.parse(userStr))
    }

    // Mock data - replace with API call
    const mockTrials: Record<string, Trial> = {
      "1": {
        _id: "1",
        title: "Diabetes Management Study",
        description: "A groundbreaking study on new insulin therapy",
        fullDescription:
          "This comprehensive clinical trial evaluates a novel insulin delivery system combined with continuous glucose monitoring technology. Participants will receive advanced training on diabetes management and have access to cutting-edge medical equipment.",
        status: "Recruiting",
        location: "New York, NY",
        phase: "Phase III",
        sponsor: "MedCorp Research",
        participantsNeeded: 100,
        currentParticipants: 42,
        startDate: "2024-06-01",
        endDate: "2025-12-31",
        condition: "Type 2 Diabetes",
        requirements: [
          "Age 18-70",
          "Diagnosed Type 2 Diabetes",
          "HbA1c between 7.0-10.5%",
          "Willing to attend monthly visits",
          "Stable health condition",
        ],
        sideEffects: ["Mild injection site reactions", "Occasional headaches", "Fatigue in first week"],
        benefits: [
          "Free diabetes management education",
          "Monthly stipend",
          "Free medical monitoring",
          "Access to new therapy",
        ],
        contactName: "Dr. Sarah Mitchell",
        contactEmail: "sarah.mitchell@medcorp.com",
        contactPhone: "+1-555-0123",
      },
    }

    setTrial(mockTrials[trialId] || null)
    setLoading(false)
  }, [trialId, router])

  const handleEnroll = async () => {
    if (!user || !trial) return

    setEnrolling(true)
    try {
      const response = await fetch(`/api/trials/${trial._id}/enroll`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ userId: user.id }),
      })

      if (response.ok) {
        setEnrolled(true)
        // Send SMS notification
        await fetch("/api/sms/send", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({
            phoneNumber: user.phone || "+1234567890",
            message: `Welcome to ${trial.title}! You've been enrolled. Check CuraLink for next steps.`,
          }),
        })
      }
    } catch (error) {
      console.error("[v0] Enrollment error:", error)
    } finally {
      setEnrolling(false)
    }
  }

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-background">
        <div className="text-muted-foreground">Loading trial details...</div>
      </div>
    )
  }

  if (!trial) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-background">
        <div className="text-center space-y-4">
          <p className="text-muted-foreground">Trial not found</p>
          <Link href="/trials">
            <Button>Back to Trials</Button>
          </Link>
        </div>
      </div>
    )
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-background via-background to-secondary/20">
      {/* Header */}
      <header className="border-b border-border/40 bg-card/60 backdrop-blur-xl sticky top-0 z-50">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-4">
          <Link href="/trials">
            <Button variant="ghost" size="sm" className="gap-2 mb-4">
              <ArrowLeft className="w-4 h-4" />
              Back to Trials
            </Button>
          </Link>
          <div className="flex items-start justify-between gap-4">
            <div>
              <div className="inline-block px-3 py-1 bg-primary/10 text-primary text-xs font-semibold rounded-full mb-2">
                {trial.phase}
              </div>
              <h1 className="text-3xl font-bold">{trial.title}</h1>
            </div>
            <div className="flex gap-2">
              <Button variant="outline" size="icon">
                <Heart className="w-4 h-4" />
              </Button>
              <Button variant="outline" size="icon">
                <Share2 className="w-4 h-4" />
              </Button>
            </div>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <div className="grid lg:grid-cols-3 gap-8">
          {/* Content */}
          <div className="lg:col-span-2 space-y-8">
            {/* Overview */}
            <Card className="p-6 border-l-4 border-l-primary">
              <h2 className="text-xl font-bold mb-4">Overview</h2>
              <p className="text-muted-foreground mb-6">{trial.fullDescription}</p>

              <div className="grid md:grid-cols-2 gap-4">
                <div className="flex items-center gap-3">
                  <MapPin className="w-5 h-5 text-primary" />
                  <div>
                    <p className="text-xs text-muted-foreground">Location</p>
                    <p className="font-semibold">{trial.location}</p>
                  </div>
                </div>
                <div className="flex items-center gap-3">
                  <Users className="w-5 h-5 text-accent" />
                  <div>
                    <p className="text-xs text-muted-foreground">Participants</p>
                    <p className="font-semibold">
                      {trial.currentParticipants} / {trial.participantsNeeded}
                    </p>
                  </div>
                </div>
                <div className="flex items-center gap-3">
                  <Clock className="w-5 h-5 text-secondary" />
                  <div>
                    <p className="text-xs text-muted-foreground">Duration</p>
                    <p className="font-semibold">
                      {new Date(trial.startDate).toLocaleDateString()} - {new Date(trial.endDate).toLocaleDateString()}
                    </p>
                  </div>
                </div>
                <div className="flex items-center gap-3">
                  <CheckCircle className="w-5 h-5 text-green-500" />
                  <div>
                    <p className="text-xs text-muted-foreground">Status</p>
                    <p className="font-semibold text-green-600">{trial.status}</p>
                  </div>
                </div>
              </div>
            </Card>

            {/* Requirements */}
            <Card className="p-6">
              <h2 className="text-xl font-bold mb-4">Eligibility Requirements</h2>
              <ul className="space-y-2">
                {trial.requirements.map((req, idx) => (
                  <li key={idx} className="flex items-start gap-3">
                    <CheckCircle className="w-5 h-5 text-green-500 flex-shrink-0 mt-0.5" />
                    <span className="text-muted-foreground">{req}</span>
                  </li>
                ))}
              </ul>
            </Card>

            {/* Benefits & Side Effects */}
            <div className="grid md:grid-cols-2 gap-6">
              <Card className="p-6 bg-green-50 dark:bg-green-950/20 border-green-200 dark:border-green-900/30">
                <h3 className="font-bold mb-4 text-green-900 dark:text-green-100">Expected Benefits</h3>
                <ul className="space-y-2">
                  {trial.benefits.map((benefit, idx) => (
                    <li key={idx} className="flex items-start gap-2 text-green-800 dark:text-green-200 text-sm">
                      <CheckCircle className="w-4 h-4 flex-shrink-0 mt-0.5" />
                      {benefit}
                    </li>
                  ))}
                </ul>
              </Card>

              <Card className="p-6 bg-yellow-50 dark:bg-yellow-950/20 border-yellow-200 dark:border-yellow-900/30">
                <h3 className="font-bold mb-4 text-yellow-900 dark:text-yellow-100">Possible Side Effects</h3>
                <ul className="space-y-2">
                  {trial.sideEffects.map((effect, idx) => (
                    <li key={idx} className="flex items-start gap-2 text-yellow-800 dark:text-yellow-200 text-sm">
                      <div className="w-1.5 h-1.5 rounded-full bg-current mt-2 flex-shrink-0" />
                      {effect}
                    </li>
                  ))}
                </ul>
              </Card>
            </div>
          </div>

          {/* Sidebar */}
          <div className="lg:col-span-1">
            {/* Enrollment Card */}
            <Card className="p-6 sticky top-24 border-l-4 border-l-primary">
              <h3 className="font-bold text-lg mb-4">Ready to Join?</h3>

              {enrolled ? (
                <div className="text-center py-4 space-y-2">
                  <CheckCircle className="w-12 h-12 text-green-500 mx-auto" />
                  <p className="font-semibold text-green-600">Successfully Enrolled!</p>
                  <p className="text-sm text-muted-foreground">Check your email and SMS for next steps</p>
                </div>
              ) : (
                <>
                  <p className="text-sm text-muted-foreground mb-4">
                    Join this important research and contribute to medical advancement
                  </p>
                  <Button onClick={handleEnroll} disabled={enrolling} className="w-full mb-3" size="lg">
                    {enrolling ? "Enrolling..." : "Enroll Now"}
                  </Button>
                  <Button variant="outline" className="w-full bg-transparent">
                    Learn More
                  </Button>
                </>
              )}

              <div className="mt-6 pt-6 border-t border-border space-y-4">
                <h4 className="font-semibold text-sm">Contact Research Team</h4>

                <a
                  href={`mailto:${trial.contactEmail}`}
                  className="flex items-center gap-3 p-3 rounded-lg hover:bg-secondary transition"
                >
                  <Mail className="w-5 h-5 text-muted-foreground" />
                  <div className="text-sm">
                    <p className="font-medium">{trial.contactName}</p>
                    <p className="text-xs text-muted-foreground truncate">{trial.contactEmail}</p>
                  </div>
                </a>

                <a
                  href={`tel:${trial.contactPhone}`}
                  className="flex items-center gap-3 p-3 rounded-lg hover:bg-secondary transition"
                >
                  <Phone className="w-5 h-5 text-muted-foreground" />
                  <div className="text-sm">
                    <p className="font-medium">Call Now</p>
                    <p className="text-xs text-muted-foreground">{trial.contactPhone}</p>
                  </div>
                </a>
              </div>
            </Card>

            {/* Info Card */}
            <Card className="p-4 mt-4 bg-secondary/30 border-secondary">
              <p className="text-xs text-muted-foreground">
                This trial is conducted according to international ethical guidelines. Your privacy and safety are our
                priority.
              </p>
            </Card>
          </div>
        </div>
      </main>
    </div>
  )
}

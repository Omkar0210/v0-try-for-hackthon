"use client"

import { useState, useEffect } from "react"
import { Card } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import Link from "next/link"
import { Search, MapPin, Users, Clock, ArrowRight, Filter, Loader, CheckCircle } from "lucide-react"
import { useRouter } from "next/navigation"

interface Trial {
  _id: string
  title: string
  description: string
  status: string
  location: string
  phase: string
  sponsor: string
  participantsNeeded: number
  startDate: string
  endDate: string
  condition: string
  featured?: boolean
}

export default function TrialsPage() {
  const router = useRouter()
  const [trials, setTrials] = useState<Trial[]>([])
  const [searchTerm, setSearchTerm] = useState("")
  const [phaseFilter, setPhaseFilter] = useState("all")
  const [loading, setLoading] = useState(true)
  const [user, setUser] = useState<any>(null)

  useEffect(() => {
    const userStr = localStorage.getItem("user")
    if (!userStr) {
      router.push("/auth")
    } else {
      setUser(JSON.parse(userStr))
    }

    // Mock data - replace with API call
    setTrials([
      {
        _id: "1",
        title: "Diabetes Management Study",
        description: "A groundbreaking study on new insulin therapy with advanced glucose monitoring",
        status: "Recruiting",
        location: "New York, NY",
        phase: "Phase III",
        sponsor: "MedCorp Research",
        participantsNeeded: 100,
        startDate: "2024-06-01",
        endDate: "2025-12-31",
        condition: "Type 2 Diabetes",
        featured: true,
      },
      {
        _id: "2",
        title: "Alzheimer's Prevention Trial",
        description: "Testing preventive measures for cognitive decline in aging populations",
        status: "Recruiting",
        location: "Boston, MA",
        phase: "Phase II",
        sponsor: "Brain Health Institute",
        participantsNeeded: 50,
        startDate: "2024-07-15",
        endDate: "2025-06-30",
        condition: "Alzheimer's Disease",
        featured: true,
      },
      {
        _id: "3",
        title: "Cancer Immunotherapy Study",
        description: "Novel approach to cancer treatment using cutting-edge immunotherapy",
        status: "Recruiting",
        location: "San Francisco, CA",
        phase: "Phase I",
        sponsor: "Oncology Innovations",
        participantsNeeded: 25,
        startDate: "2024-08-01",
        endDate: "2026-01-31",
        condition: "Melanoma",
      },
      {
        _id: "4",
        title: "Hypertension Management Study",
        description: "New approaches to blood pressure control in resistant hypertension",
        status: "Recruiting",
        location: "Chicago, IL",
        phase: "Phase III",
        sponsor: "Cardiology Research Group",
        participantsNeeded: 75,
        startDate: "2024-09-01",
        endDate: "2025-09-01",
        condition: "Hypertension",
      },
      {
        _id: "5",
        title: "Depression Treatment Trial",
        description: "Evaluating new therapeutic approach for treatment-resistant depression",
        status: "Recruiting",
        location: "Seattle, WA",
        phase: "Phase II",
        sponsor: "Mental Health Institute",
        participantsNeeded: 60,
        startDate: "2024-10-01",
        endDate: "2025-10-01",
        condition: "Depression",
      },
      {
        _id: "6",
        title: "Arthritis Management Study",
        description: "Testing new biologics for rheumatoid arthritis management",
        status: "Recruiting",
        location: "Los Angeles, CA",
        phase: "Phase III",
        sponsor: "Rheumatology Research",
        participantsNeeded: 80,
        startDate: "2024-11-01",
        endDate: "2025-11-01",
        condition: "Rheumatoid Arthritis",
      },
    ])
    setLoading(false)
  }, [router])

  const filteredTrials = trials.filter((trial) => {
    const matchesSearch =
      trial.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
      trial.description.toLowerCase().includes(searchTerm.toLowerCase()) ||
      trial.condition.toLowerCase().includes(searchTerm.toLowerCase())

    const matchesPhase = phaseFilter === "all" || trial.phase === phaseFilter

    return matchesSearch && matchesPhase
  })

  const featuredTrials = trials.filter((t) => t.featured)

  return (
    <div className="min-h-screen bg-gradient-to-br from-background via-background to-secondary/20">
      {/* Header */}
      <header className="border-b border-border/40 bg-card/60 backdrop-blur-xl sticky top-0 z-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6">
          <Link href="/dashboard" className="text-primary hover:underline mb-4 inline-block text-sm font-medium">
            ← Back to Dashboard
          </Link>
          <div className="space-y-2">
            <h1 className="text-3xl font-bold bg-gradient-to-r from-primary to-accent bg-clip-text text-transparent">
              Find Clinical Trials
            </h1>
            <p className="text-muted-foreground">
              Discover trials matching your health profile and interests. Join groundbreaking research.
            </p>
          </div>
        </div>
      </header>

      {/* Featured Trials Section */}
      {featuredTrials.length > 0 && (
        <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
          <h2 className="text-2xl font-bold mb-6">Featured Trials</h2>
          <div className="grid md:grid-cols-2 gap-6">
            {featuredTrials.map((trial) => (
              <Link key={trial._id} href={`/trials/${trial._id}`}>
                <Card className="p-6 hover:shadow-2xl transition cursor-pointer h-full relative overflow-hidden group border-primary/20 bg-gradient-to-br from-card to-primary/5">
                  <div className="absolute top-0 right-0 w-24 h-24 bg-primary/10 rounded-full -mr-8 -mt-8 group-hover:scale-150 transition" />
                  <div className="relative z-10">
                    <div className="flex items-start justify-between mb-3">
                      <div className="inline-block px-3 py-1 bg-primary/20 text-primary text-xs font-semibold rounded-full">
                        {trial.phase}
                      </div>
                      <span className="text-xs font-medium text-green-600 bg-green-100 px-2 py-1 rounded">
                        Featured
                      </span>
                    </div>
                    <h3 className="text-xl font-bold mb-2 line-clamp-2">{trial.title}</h3>
                    <p className="text-sm text-muted-foreground mb-4 line-clamp-2">{trial.description}</p>
                    <div className="grid grid-cols-2 gap-2 text-sm mb-4">
                      <div className="flex items-center gap-2 text-muted-foreground">
                        <MapPin className="w-4 h-4 flex-shrink-0" />
                        {trial.location}
                      </div>
                      <div className="flex items-center gap-2 text-muted-foreground">
                        <Users className="w-4 h-4 flex-shrink-0" />
                        {trial.participantsNeeded} spots
                      </div>
                    </div>
                    <div className="flex items-center gap-2 text-primary font-semibold group-hover:gap-3 transition">
                      Learn More <ArrowRight className="w-4 h-4" />
                    </div>
                  </div>
                </Card>
              </Link>
            ))}
          </div>
        </section>
      )}

      {/* Search & Filter */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <div className="space-y-4">
          <div className="relative">
            <Search className="absolute left-4 top-3 w-5 h-5 text-muted-foreground" />
            <Input
              type="text"
              placeholder="Search trials by condition, title, or sponsor..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="pl-12 h-12 bg-card border-border focus:ring-primary"
            />
          </div>

          <div className="flex gap-2 flex-wrap">
            <button
              onClick={() => setPhaseFilter("all")}
              className={`px-4 py-2 rounded-lg font-medium text-sm transition ${
                phaseFilter === "all"
                  ? "bg-primary text-primary-foreground"
                  : "bg-secondary text-secondary-foreground hover:bg-secondary/80"
              }`}
            >
              All Phases
            </button>
            {["Phase I", "Phase II", "Phase III", "Phase IV"].map((phase) => (
              <button
                key={phase}
                onClick={() => setPhaseFilter(phase)}
                className={`px-4 py-2 rounded-lg font-medium text-sm transition ${
                  phaseFilter === phase
                    ? "bg-primary text-primary-foreground"
                    : "bg-secondary text-secondary-foreground hover:bg-secondary/80"
                }`}
              >
                {phase}
              </button>
            ))}
          </div>
        </div>
      </section>

      {/* Trials Grid */}
      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 pb-12">
        {loading ? (
          <div className="text-center py-12">
            <Loader className="w-8 h-8 animate-spin mx-auto text-primary mb-4" />
            <p className="text-muted-foreground">Loading trials...</p>
          </div>
        ) : filteredTrials.length === 0 ? (
          <Card className="p-12 text-center bg-secondary/30 border-secondary">
            <Filter className="w-12 h-12 text-muted-foreground mx-auto mb-4 opacity-50" />
            <p className="text-muted-foreground mb-4">No trials found matching your search</p>
            <Button onClick={() => setSearchTerm("")} variant="outline">
              Clear Filters
            </Button>
          </Card>
        ) : (
          <div>
            <p className="text-sm text-muted-foreground mb-6">
              Found <span className="font-semibold text-foreground">{filteredTrials.length}</span> trials
            </p>
            <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
              {filteredTrials.map((trial) => (
                <Link key={trial._id} href={`/trials/${trial._id}`}>
                  <Card className="p-6 hover:shadow-lg transition cursor-pointer h-full flex flex-col group border-l-4 border-l-primary hover:border-l-accent">
                    <div className="flex-1 mb-4">
                      <div className="flex items-center justify-between mb-2">
                        <div className="inline-block px-3 py-1 bg-primary/10 text-primary text-xs font-semibold rounded-full group-hover:bg-accent/10 group-hover:text-accent transition">
                          {trial.phase}
                        </div>
                        <span className="text-xs font-medium text-green-600">
                          <CheckCircle className="w-3 h-3 inline mr-1" />
                          {trial.status}
                        </span>
                      </div>
                      <h3 className="text-lg font-bold mb-2 line-clamp-2 group-hover:text-primary transition">
                        {trial.title}
                      </h3>
                      <p className="text-sm text-muted-foreground mb-4 line-clamp-2">{trial.description}</p>
                      <div className="space-y-2 text-sm">
                        <div className="flex items-center gap-2 text-muted-foreground">
                          <MapPin className="w-4 h-4 flex-shrink-0" />
                          {trial.location}
                        </div>
                        <div className="flex items-center gap-2 text-muted-foreground">
                          <Users className="w-4 h-4 flex-shrink-0" />
                          {trial.participantsNeeded} spots available
                        </div>
                        <div className="flex items-center gap-2 text-muted-foreground">
                          <Clock className="w-4 h-4 flex-shrink-0" />
                          {new Date(trial.endDate).toLocaleDateString()}
                        </div>
                      </div>
                    </div>
                    <Button className="w-full group-hover:gap-2 gap-0 transition">
                      View Details
                      <ArrowRight className="w-4 h-4" />
                    </Button>
                  </Card>
                </Link>
              ))}
            </div>
          </div>
        )}
      </main>
    </div>
  )
}

"use client"

import { useEffect, useState } from "react"
import { useRouter } from "next/navigation"
import { Card } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { VoiceAgentWidget } from "@/components/voice/voice-agent-widget"
import { ArrowLeft, Phone, Clock, MessageSquare, AlertCircle } from "lucide-react"
import Link from "next/link"

interface User {
  id: string
  name: string
  email: string
  role: string
}

export default function VoiceAgentPage() {
  const router = useRouter()
  const [user, setUser] = useState<User | null>(null)
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    const userStr = localStorage.getItem("user")
    const token = localStorage.getItem("token")

    if (!userStr || !token) {
      router.push("/auth")
    } else {
      setUser(JSON.parse(userStr))
      setLoading(false)
    }
  }, [router])

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="text-muted-foreground">Loading...</div>
      </div>
    )
  }

  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <header className="border-b border-border bg-card">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-4 flex items-center gap-4">
          <Link href="/dashboard">
            <Button variant="ghost" size="sm" className="gap-2">
              <ArrowLeft className="w-4 h-4" />
              Back
            </Button>
          </Link>
          <div>
            <h1 className="text-2xl font-bold text-foreground">AI Voice Assistant</h1>
            <p className="text-sm text-muted-foreground">24/7 Support for Your Clinical Trial Questions</p>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        <div className="grid md:grid-cols-3 gap-6 mb-8">
          {/* Voice Widget */}
          <div className="md:col-span-2">
            <VoiceAgentWidget patientName={user?.name} patientEmail={user?.email} />
          </div>

          {/* Info Cards */}
          <div className="space-y-4">
            <Card className="p-4">
              <div className="flex items-start gap-3">
                <Phone className="w-5 h-5 text-primary mt-0.5 flex-shrink-0" />
                <div>
                  <h3 className="font-semibold text-sm mb-1">Available 24/7</h3>
                  <p className="text-xs text-muted-foreground">Call anytime for instant support</p>
                </div>
              </div>
            </Card>

            <Card className="p-4">
              <div className="flex items-start gap-3">
                <Clock className="w-5 h-5 text-accent mt-0.5 flex-shrink-0" />
                <div>
                  <h3 className="font-semibold text-sm mb-1">Quick Response</h3>
                  <p className="text-xs text-muted-foreground">Get answers in seconds, not hours</p>
                </div>
              </div>
            </Card>

            <Card className="p-4">
              <div className="flex items-start gap-3">
                <MessageSquare className="w-5 h-5 text-secondary mt-0.5 flex-shrink-0" />
                <div>
                  <h3 className="font-semibold text-sm mb-1">Understand Trials</h3>
                  <p className="text-xs text-muted-foreground">Learn details about your enrolled trials</p>
                </div>
              </div>
            </Card>
          </div>
        </div>

        {/* Features */}
        <Card className="p-8 bg-secondary/50 border-secondary">
          <h2 className="text-xl font-semibold mb-6">What You Can Ask</h2>
          <div className="grid md:grid-cols-2 gap-4">
            <div className="flex gap-3">
              <div className="w-2 h-2 rounded-full bg-primary mt-2 flex-shrink-0" />
              <div>
                <p className="font-medium text-sm">Trial Information</p>
                <p className="text-xs text-muted-foreground">Details about your current trials and requirements</p>
              </div>
            </div>
            <div className="flex gap-3">
              <div className="w-2 h-2 rounded-full bg-accent mt-2 flex-shrink-0" />
              <div>
                <p className="font-medium text-sm">Appointment Details</p>
                <p className="text-xs text-muted-foreground">Get reminders and scheduling information</p>
              </div>
            </div>
            <div className="flex gap-3">
              <div className="w-2 h-2 rounded-full bg-primary mt-2 flex-shrink-0" />
              <div>
                <p className="font-medium text-sm">Health Questions</p>
                <p className="text-xs text-muted-foreground">General information about your trial conditions</p>
              </div>
            </div>
            <div className="flex gap-3">
              <div className="w-2 h-2 rounded-full bg-accent mt-2 flex-shrink-0" />
              <div>
                <p className="font-medium text-sm">Support & Resources</p>
                <p className="text-xs text-muted-foreground">Connect with research coordinators if needed</p>
              </div>
            </div>
          </div>
        </Card>

        {/* Privacy Notice */}
        <Card className="p-4 mt-6 border-yellow-200 bg-yellow-50 dark:bg-yellow-900/20">
          <div className="flex gap-3">
            <AlertCircle className="w-5 h-5 text-yellow-600 flex-shrink-0 mt-0.5" />
            <div>
              <h3 className="font-semibold text-sm text-yellow-900 dark:text-yellow-200 mb-1">Privacy & Security</h3>
              <p className="text-xs text-yellow-800 dark:text-yellow-300">
                All conversations are encrypted and stored securely. Your health information is never shared without
                your consent.
              </p>
            </div>
          </div>
        </Card>
      </main>
    </div>
  )
}

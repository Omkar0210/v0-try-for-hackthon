"use client"

import { useEffect, useState } from "react"
import { useRouter } from "next/navigation"
import { Button } from "@/components/ui/button"
import { Card } from "@/components/ui/card"
import { LogOut, Search, MessageSquare, Phone, Users, Calendar, Sparkles, ArrowRight, TrendingUp } from "lucide-react"
import Link from "next/link"

interface User {
  id: string
  name: string
  email: string
  role: string
}

interface DashboardStats {
  activeTrials: number
  upcomingAppointments: number
  messages: number
}

export default function DashboardPage() {
  const router = useRouter()
  const [user, setUser] = useState<User | null>(null)
  const [stats, setStats] = useState<DashboardStats>({
    activeTrials: 0,
    upcomingAppointments: 0,
    messages: 0,
  })
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    const userStr = localStorage.getItem("user")
    const token = localStorage.getItem("token")

    if (!userStr || !token) {
      router.push("/auth")
    } else {
      setUser(JSON.parse(userStr))
      setLoading(false)
    }
  }, [router])

  const handleLogout = () => {
    localStorage.removeItem("token")
    localStorage.removeItem("user")
    router.push("/")
  }

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-background">
        <div className="text-muted-foreground">Loading...</div>
      </div>
    )
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-background via-background to-secondary/20">
      {/* Header */}
      <header className="border-b border-border/40 bg-card/60 backdrop-blur-xl sticky top-0 z-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-4 flex items-center justify-between">
          <div className="space-y-1">
            <div className="flex items-center gap-2">
              <div className="w-2 h-2 rounded-full bg-green-500" />
              <h1 className="text-2xl font-bold bg-gradient-to-r from-primary to-accent bg-clip-text text-transparent">
                Welcome back, {user?.name}!
              </h1>
            </div>
            <p className="text-sm text-muted-foreground capitalize">
              {user?.role === "patient" ? "Patient" : "Researcher"} Dashboard
            </p>
          </div>
          <Button
            variant="outline"
            onClick={handleLogout}
            className="gap-2 hover:bg-destructive/10 hover:text-destructive bg-transparent"
          >
            <LogOut className="w-4 h-4" />
            Logout
          </Button>
        </div>
      </header>

      {/* Main Content */}
      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        {user?.role === "patient" ? (
          <div className="space-y-8">
            {/* Quick Stats */}
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              <Card className="p-6 border-l-4 border-l-primary hover:shadow-lg transition">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm text-muted-foreground mb-1">Active Trials</p>
                    <p className="text-3xl font-bold">{stats.activeTrials}</p>
                  </div>
                  <TrendingUp className="w-8 h-8 text-primary/50" />
                </div>
              </Card>
              <Card className="p-6 border-l-4 border-l-accent hover:shadow-lg transition">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm text-muted-foreground mb-1">Upcoming Appointments</p>
                    <p className="text-3xl font-bold">{stats.upcomingAppointments}</p>
                  </div>
                  <Calendar className="w-8 h-8 text-accent/50" />
                </div>
              </Card>
              <Card className="p-6 border-l-4 border-l-secondary hover:shadow-lg transition">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm text-muted-foreground mb-1">Messages</p>
                    <p className="text-3xl font-bold">{stats.messages}</p>
                  </div>
                  <MessageSquare className="w-8 h-8 text-secondary/50" />
                </div>
              </Card>
            </div>

            {/* Featured Actions - Voice & Chat */}
            <div className="grid md:grid-cols-2 gap-6">
              {/* AI Voice Assistant - Featured */}
              <Link href="/voice-agent">
                <Card className="p-8 hover:shadow-2xl transition cursor-pointer h-full relative overflow-hidden group bg-gradient-to-br from-card to-primary/5 border-primary/20">
                  <div className="absolute top-0 right-0 w-32 h-32 bg-primary/10 rounded-full -mr-8 -mt-8 group-hover:scale-150 transition" />
                  <div className="relative z-10">
                    <div className="inline-flex items-center justify-center w-12 h-12 rounded-lg bg-primary/10 mb-4 group-hover:bg-primary/20 transition">
                      <Phone className="w-6 h-6 text-primary" />
                    </div>
                    <h2 className="text-2xl font-bold mb-2">Voice Assistant</h2>
                    <p className="text-muted-foreground mb-6">
                      Call our AI assistant powered by advanced voice technology. Available 24/7 for instant answers
                      about your trials.
                    </p>
                    <div className="flex items-center gap-2 text-primary font-semibold group-hover:gap-3 transition">
                      <span>Start Call</span>
                      <ArrowRight className="w-4 h-4" />
                    </div>
                  </div>
                </Card>
              </Link>

              {/* AI Chat Support - Featured */}
              <Link href="/chat">
                <Card className="p-8 hover:shadow-2xl transition cursor-pointer h-full relative overflow-hidden group bg-gradient-to-br from-card to-accent/5 border-accent/20">
                  <div className="absolute top-0 right-0 w-32 h-32 bg-accent/10 rounded-full -mr-8 -mt-8 group-hover:scale-150 transition" />
                  <div className="relative z-10">
                    <div className="inline-flex items-center justify-center w-12 h-12 rounded-lg bg-accent/10 mb-4 group-hover:bg-accent/20 transition">
                      <Sparkles className="w-6 h-6 text-accent" />
                    </div>
                    <h2 className="text-2xl font-bold mb-2">Chat with AI</h2>
                    <p className="text-muted-foreground mb-6">
                      Get instant answers to questions about clinical trials, enrollment, and your health using our
                      intelligent chatbot.
                    </p>
                    <div className="flex items-center gap-2 text-accent font-semibold group-hover:gap-3 transition">
                      <span>Start Chat</span>
                      <ArrowRight className="w-4 h-4" />
                    </div>
                  </div>
                </Card>
              </Link>
            </div>

            {/* Main Navigation Grid */}
            <div className="space-y-4">
              <h3 className="text-lg font-semibold text-foreground">Quick Access</h3>
              <div className="grid md:grid-cols-2 gap-4">
                {/* Find Trials */}
                <Link href="/trials">
                  <Card className="p-6 hover:shadow-lg transition cursor-pointer group">
                    <div className="flex items-start justify-between mb-4">
                      <Search className="w-6 h-6 text-primary group-hover:scale-110 transition" />
                      <ArrowRight className="w-4 h-4 text-muted-foreground opacity-0 group-hover:opacity-100 transition" />
                    </div>
                    <h3 className="font-semibold mb-1">Find Clinical Trials</h3>
                    <p className="text-sm text-muted-foreground mb-4">Discover trials matching your health profile</p>
                    <Button size="sm" variant="outline" className="w-full bg-transparent">
                      Browse Trials
                    </Button>
                  </Card>
                </Link>

                {/* My Trials */}
                <Link href="/my-trials">
                  <Card className="p-6 hover:shadow-lg transition cursor-pointer group">
                    <div className="flex items-start justify-between mb-4">
                      <MessageSquare className="w-6 h-6 text-secondary group-hover:scale-110 transition" />
                      <ArrowRight className="w-4 h-4 text-muted-foreground opacity-0 group-hover:opacity-100 transition" />
                    </div>
                    <h3 className="font-semibold mb-1">My Trials</h3>
                    <p className="text-sm text-muted-foreground mb-4">
                      Track enrolled trials and researcher communication
                    </p>
                    <Button size="sm" variant="outline" className="w-full bg-transparent">
                      View Trials
                    </Button>
                  </Card>
                </Link>

                {/* Appointments */}
                <Link href="/appointments">
                  <Card className="p-6 hover:shadow-lg transition cursor-pointer group">
                    <div className="flex items-start justify-between mb-4">
                      <Calendar className="w-6 h-6 text-accent group-hover:scale-110 transition" />
                      <ArrowRight className="w-4 h-4 text-muted-foreground opacity-0 group-hover:opacity-100 transition" />
                    </div>
                    <h3 className="font-semibold mb-1">My Appointments</h3>
                    <p className="text-sm text-muted-foreground mb-4">Schedule and receive SMS reminders</p>
                    <Button size="sm" variant="outline" className="w-full bg-transparent">
                      Manage Appointments
                    </Button>
                  </Card>
                </Link>

                {/* Community Forums */}
                <Link href="/forums">
                  <Card className="p-6 hover:shadow-lg transition cursor-pointer group">
                    <div className="flex items-start justify-between mb-4">
                      <Users className="w-6 h-6 text-primary group-hover:scale-110 transition" />
                      <ArrowRight className="w-4 h-4 text-muted-foreground opacity-0 group-hover:opacity-100 transition" />
                    </div>
                    <h3 className="font-semibold mb-1">Community Forums</h3>
                    <p className="text-sm text-muted-foreground mb-4">Connect with other trial participants</p>
                    <Button size="sm" variant="outline" className="w-full bg-transparent">
                      Join Forums
                    </Button>
                  </Card>
                </Link>
              </div>
            </div>

            {/* Info Banner */}
            <Card className="p-6 bg-gradient-to-r from-primary/10 to-accent/10 border-primary/20">
              <h3 className="font-semibold mb-2">Get the Most Out of CuraLink</h3>
              <p className="text-sm text-muted-foreground mb-4">
                Use our AI voice and chat assistants to get instant answers. Schedule appointments easily with SMS
                reminders. Browse and enroll in trials that match your profile.
              </p>
              <div className="flex gap-3">
                <Link href="/chat">
                  <Button size="sm" variant="default">
                    Try Chat Now
                  </Button>
                </Link>
                <Link href="/voice-agent">
                  <Button size="sm" variant="outline">
                    Try Voice
                  </Button>
                </Link>
              </div>
            </Card>
          </div>
        ) : (
          <div className="space-y-8">
            {/* Researcher Quick Stats */}
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              <Card className="p-6 border-l-4 border-l-primary hover:shadow-lg transition">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm text-muted-foreground mb-1">Active Trials</p>
                    <p className="text-3xl font-bold">3</p>
                  </div>
                  <TrendingUp className="w-8 h-8 text-primary/50" />
                </div>
              </Card>
              <Card className="p-6 border-l-4 border-l-accent hover:shadow-lg transition">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm text-muted-foreground mb-1">Participants</p>
                    <p className="text-3xl font-bold">24</p>
                  </div>
                  <Users className="w-8 h-8 text-accent/50" />
                </div>
              </Card>
              <Card className="p-6 border-l-4 border-l-secondary hover:shadow-lg transition">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm text-muted-foreground mb-1">Pending Messages</p>
                    <p className="text-3xl font-bold">5</p>
                  </div>
                  <MessageSquare className="w-8 h-8 text-secondary/50" />
                </div>
              </Card>
            </div>

            {/* Researcher Main Grid */}
            <div className="grid md:grid-cols-2 gap-6">
              <Link href="/researcher/trials">
                <Card className="p-8 hover:shadow-lg transition cursor-pointer h-full relative overflow-hidden group bg-gradient-to-br from-card to-primary/5 border-primary/20">
                  <div className="absolute top-0 right-0 w-32 h-32 bg-primary/10 rounded-full -mr-8 -mt-8 group-hover:scale-150 transition" />
                  <div className="relative z-10">
                    <Search className="w-8 h-8 text-primary mb-4 group-hover:scale-110 transition" />
                    <h2 className="text-2xl font-bold mb-2">Manage Trials</h2>
                    <p className="text-muted-foreground mb-6">Create, edit, and monitor your clinical trials</p>
                    <div className="flex items-center gap-2 text-primary font-semibold group-hover:gap-3 transition">
                      <span>Go to Trials</span>
                      <ArrowRight className="w-4 h-4" />
                    </div>
                  </div>
                </Card>
              </Link>

              <Link href="/researcher/participants">
                <Card className="p-8 hover:shadow-lg transition cursor-pointer h-full relative overflow-hidden group bg-gradient-to-br from-card to-accent/5 border-accent/20">
                  <div className="absolute top-0 right-0 w-32 h-32 bg-accent/10 rounded-full -mr-8 -mt-8 group-hover:scale-150 transition" />
                  <div className="relative z-10">
                    <Users className="w-8 h-8 text-accent mb-4 group-hover:scale-110 transition" />
                    <h2 className="text-2xl font-bold mb-2">Find Participants</h2>
                    <p className="text-muted-foreground mb-6">Connect with qualified patients for your research</p>
                    <div className="flex items-center gap-2 text-accent font-semibold group-hover:gap-3 transition">
                      <span>Find Participants</span>
                      <ArrowRight className="w-4 h-4" />
                    </div>
                  </div>
                </Card>
              </Link>

              <Link href="/chat">
                <Card className="p-6 hover:shadow-lg transition cursor-pointer group">
                  <div className="flex items-start justify-between mb-4">
                    <MessageSquare className="w-6 h-6 text-secondary group-hover:scale-110 transition" />
                    <ArrowRight className="w-4 h-4 text-muted-foreground opacity-0 group-hover:opacity-100 transition" />
                  </div>
                  <h3 className="font-semibold mb-1">Messages</h3>
                  <p className="text-sm text-muted-foreground mb-4">Communicate with trial participants</p>
                  <Button size="sm" variant="outline" className="w-full bg-transparent">
                    View Messages
                  </Button>
                </Card>
              </Link>

              <Link href="/settings">
                <Card className="p-6 hover:shadow-lg transition cursor-pointer group">
                  <div className="flex items-start justify-between mb-4">
                    <Phone className="w-6 h-6 text-destructive group-hover:scale-110 transition" />
                    <ArrowRight className="w-4 h-4 text-muted-foreground opacity-0 group-hover:opacity-100 transition" />
                  </div>
                  <h3 className="font-semibold mb-1">Settings</h3>
                  <p className="text-sm text-muted-foreground mb-4">Configure messaging preferences</p>
                  <Button size="sm" variant="outline" className="w-full bg-transparent">
                    Configure
                  </Button>
                </Card>
              </Link>
            </div>
          </div>
        )}
      </main>
    </div>
  )
}
